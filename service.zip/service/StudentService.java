package edu.ccrm.service;

import edu.ccrm.domain.*;
import edu.ccrm.exception.*;
import java.util.*;
import java.util.stream.Collectors;
import java.time.LocalDate;

/**
 * Student Service - demonstrates service layer pattern and business logic orchestration
 * Manages student CRUD operations and business rules
 */
public class StudentService {
    private final Map<String, Student> students;
    private final Map<String, List<Enrollment>> studentEnrollments;
    private int nextStudentNumber;
    
    public StudentService() {
        this.students = new HashMap<>();
        this.studentEnrollments = new HashMap<>();
        this.nextStudentNumber = 1;
    }
    
    // CRUD Operations with enhanced exception handling
    public Student createStudent(String regNo, String fullName, String email) throws DataValidationException {
        DataValidationException.Builder validationBuilder = DataValidationException.builder()
            .message("Student creation validation failed");
        
        // Validate registration number
        if (regNo == null || regNo.trim().isEmpty()) {
            validationBuilder.addFieldError("regNo", "Registration number is required");
        }
        
        // Validate full name
        if (fullName == null || fullName.trim().isEmpty()) {
            validationBuilder.addFieldError("fullName", "Full name is required");
        }
        
        // Validate email format if provided
        if (email != null && !email.trim().isEmpty() && !isValidEmail(email)) {
            validationBuilder.addFieldError("email", "Invalid email format");
        }
        
        // Check for validation errors before proceeding
        if (validationBuilder.build().hasFieldErrors()) {
            throw validationBuilder.build();
        }
        
        String trimmedRegNo = regNo.trim().toUpperCase();
        
        // Check for duplicate registration number
        boolean regNoExists = students.values().stream()
            .anyMatch(student -> student.getRegNo().equals(trimmedRegNo));
            
        if (regNoExists) {
            validationBuilder.addFieldError("regNo", "Registration number already exists: " + trimmedRegNo);
            throw validationBuilder.build();
        }
        
        String studentId = "STU" + String.format("%06d", nextStudentNumber++);
        Student student = new Student(studentId, trimmedRegNo, fullName, email);
        
        students.put(studentId, student);
        studentEnrollments.put(studentId, new ArrayList<>());
        
        return student;
    }
    
    public Optional<Student> findById(String studentId) {
        return Optional.ofNullable(students.get(studentId));
    }
    
    public Student getStudentById(String studentId) throws StudentNotFoundException {
        Optional<Student> student = findById(studentId);
        if (student.isEmpty()) {
            throw new StudentNotFoundException(studentId, "ID");
        }
        return student.get();
    }
    
    public Optional<Student> findByRegNo(String regNo) {
        if (regNo == null) return Optional.empty();
        
        String trimmedRegNo = regNo.trim().toUpperCase();
        return students.values().stream()
            .filter(student -> student.getRegNo().equals(trimmedRegNo))
            .findFirst();
    }
    
    public List<Student> getAllStudents() {
        return new ArrayList<>(students.values());
    }
    
    public List<Student> getActiveStudents() {
        return students.values().stream()
            .filter(Person::isActive)
            .collect(Collectors.toList());
    }
    
    public boolean updateStudent(String studentId, String fullName, String email) {
        Student student = students.get(studentId);
        if (student == null) {
            return false;
        }
        
        if (fullName != null && !fullName.trim().isEmpty()) {
            student.setFullName(fullName);
        }
        if (email != null) {
            student.setEmail(email);
        }
        
        return true;
    }
    
    public boolean deactivateStudent(String studentId) {
        Student student = students.get(studentId);
        if (student != null) {
            student.deactivate();
            return true;
        }
        return false;
    }
    
    public boolean reactivateStudent(String studentId) {
        Student student = students.get(studentId);
        if (student != null) {
            student.reactivate();
            return true;
        }
        return false;
    }
    
    // Enrollment management
    public void addEnrollment(String studentId, Enrollment enrollment) {
        if (students.containsKey(studentId)) {
            studentEnrollments.computeIfAbsent(studentId, k -> new ArrayList<>()).add(enrollment);
            
            // Update student's enrolled courses list
            Student student = students.get(studentId);
            student.enrollInCourse(enrollment.getCourseCode());
        }
    }
    
    public void removeEnrollment(String studentId, String enrollmentId) {
        List<Enrollment> enrollments = studentEnrollments.get(studentId);
        if (enrollments != null) {
            enrollments.removeIf(e -> e.getEnrollmentId().equals(enrollmentId));
        }
    }
    
    public List<Enrollment> getStudentEnrollments(String studentId) {
        return studentEnrollments.getOrDefault(studentId, new ArrayList<>());
    }
    
    public List<Enrollment> getActiveEnrollments(String studentId) {
        return getStudentEnrollments(studentId).stream()
            .filter(Enrollment::isActive)
            .collect(Collectors.toList());
    }
    
    // Business logic methods using Stream API
    public List<Student> searchStudents(String searchTerm) {
        if (searchTerm == null || searchTerm.trim().isEmpty()) {
            return getAllStudents();
        }
        
        String lowerSearchTerm = searchTerm.trim().toLowerCase();
        return students.values().stream()
            .filter(student -> 
                student.getFullName().toLowerCase().contains(lowerSearchTerm) ||
                student.getRegNo().toLowerCase().contains(lowerSearchTerm) ||
                (student.getEmail() != null && student.getEmail().toLowerCase().contains(lowerSearchTerm))
            )
            .collect(Collectors.toList());
    }
    
    public List<Student> getStudentsByGpaRange(double minGpa, double maxGpa) {
        return students.values().stream()
            .filter(student -> student.getGpa() >= minGpa && student.getGpa() <= maxGpa)
            .sorted((s1, s2) -> Double.compare(s2.getGpa(), s1.getGpa())) // Descending order
            .collect(Collectors.toList());
    }
    
    public List<Student> getTopStudents(int limit) {
        return students.values().stream()
            .filter(student -> student.getGpa() > 0)
            .sorted((s1, s2) -> Double.compare(s2.getGpa(), s1.getGpa()))
            .limit(limit)
            .collect(Collectors.toList());
    }
    
    public double calculateAverageGpa() {
        return students.values().stream()
            .filter(student -> student.getGpa() > 0)
            .mapToDouble(Student::getGpa)
            .average()
            .orElse(0.0);
    }
    
    public Map<String, Long> getStudentsByAcademicStanding() {
        return students.values().stream()
            .collect(Collectors.groupingBy(
                Student::getAcademicStanding,
                Collectors.counting()
            ));
    }
    
    // Validation methods
    public boolean canEnrollInCourse(String studentId, Course course) {
        Student student = students.get(studentId);
        if (student == null || !student.isActive()) {
            return false;
        }
        
        // Check if already enrolled
        if (student.isEnrolledInCourse(course.getCode())) {
            return false;
        }
        
        // Check credit limit (business rule) - use actual course credits
        int currentCredits = getActiveEnrollments(studentId).stream()
            .mapToInt(e -> {
                // Get actual course credits from CourseService
                // Note: This requires CourseService reference, but for now we'll use a reasonable default
                return 3; // TODO: Inject CourseService reference to get actual credits
            })
            .sum();
            
        return currentCredits + course.getCredits() <= 18; // Max 18 credits per semester
    }
    
    // Statistics and reporting
    public int getTotalStudentCount() {
        return students.size();
    }
    
    public int getActiveStudentCount() {
        return (int) students.values().stream()
            .filter(Person::isActive)
            .count();
    }
    
    public Map<String, Object> getStudentStatistics() {
        Map<String, Object> stats = new HashMap<>();
        stats.put("totalStudents", getTotalStudentCount());
        stats.put("activeStudents", getActiveStudentCount());
        stats.put("averageGpa", calculateAverageGpa());
        stats.put("academicStanding", getStudentsByAcademicStanding());
        return stats;
    }
    
    // Utility methods for validation
    private boolean isValidEmail(String email) {
        if (email == null || email.trim().isEmpty()) {
            return false;
        }
        
        String emailRegex = "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$";
        return email.matches(emailRegex);
    }
}