package edu.ccrm.cli;

import edu.ccrm.service.*;
import edu.ccrm.io.*;
import edu.ccrm.domain.*;
import java.util.*;
import java.util.stream.Collectors;
import java.nio.file.Path;
import java.nio.file.Paths;

/**
 * Command Line Interface Manager - Enhanced with full CRUD operations
 * Demonstrates comprehensive switch statements and user interactions
 */
public class CLIManager {
    private Scanner scanner;
    private boolean running;
    private MenuHelper menuHelper;
    
    // Service layer dependencies
    private StudentService studentService;
    private CourseService courseService;
    private EnrollmentService enrollmentService;
    private TranscriptService transcriptService;
    private CSVImportExportService importExportService;
    private BackupService backupService;
    
    public CLIManager() {
        this.scanner = new Scanner(System.in);
        this.menuHelper = new MenuHelper(scanner);
        this.running = false;
        initializeServices();
    }
    
    private void initializeServices() {
        // Initialize service layer
        this.studentService = new StudentService();
        this.courseService = new CourseService();
        this.enrollmentService = new EnrollmentService(studentService, courseService);
        this.transcriptService = new TranscriptService(studentService, courseService, enrollmentService);
        this.importExportService = new CSVImportExportService(studentService, courseService, enrollmentService);
        this.backupService = new BackupService(importExportService);
        
        // Create some sample data for demonstration
        createSampleData();
    }
    
    private void createSampleData() {
        try {
            // Create sample students
            Student student1 = studentService.createStudent("CS2024001", "John Smith", "john.smith@university.edu");
            Student student2 = studentService.createStudent("CS2024002", "Jane Doe", "jane.doe@university.edu");
            Student student3 = studentService.createStudent("EE2024001", "Bob Johnson", "bob.johnson@university.edu");
            
            // Create sample courses
            Course course1 = courseService.createCourse(new Course.Builder("CS101", "Introduction to Computer Science")
                .credits(3).department("Computer Science").semester(Semester.FALL).maxEnrollment(50));
            Course course2 = courseService.createCourse(new Course.Builder("MATH201", "Calculus II")
                .credits(4).department("Mathematics").semester(Semester.FALL).maxEnrollment(30));
            Course course3 = courseService.createCourse(new Course.Builder("ENG101", "Technical Writing")
                .credits(2).department("English").semester(Semester.SPRING).maxEnrollment(25));
            
            // Create sample enrollments
            enrollmentService.enrollStudent(student1.getId(), course1.getCode());
            enrollmentService.enrollStudent(student1.getId(), course2.getCode());
            enrollmentService.enrollStudent(student2.getId(), course1.getCode());
            enrollmentService.enrollStudent(student3.getId(), course3.getCode());
            
            // Record some grades
            enrollmentService.recordGrade(student1.getId(), course1.getCode(), 85);
            enrollmentService.recordGrade(student2.getId(), course1.getCode(), 92);
            
        } catch (Exception e) {
            System.out.println("Note: Sample data creation failed - starting with empty system");
        }
    }
    
    public void start() {
        running = true;
        menuHelper.displayHeader("Campus Course & Records Manager (CCRM)");
        System.out.println("A comprehensive Java SE application demonstrating advanced OOP concepts");
        
        while (running) {
            displayMainMenu();
            int choice = menuHelper.getMenuChoice(7);
            handleMenuChoice(choice);
        }
        
        scanner.close();
    }
    
    private void displayMainMenu() {
        System.out.println("\n=== MAIN MENU ===");
        System.out.println("1. Student Management");
        System.out.println("2. Course Management"); 
        System.out.println("3. Enrollment Management");
        System.out.println("4. Grade Management");
        System.out.println("5. Transcript & Reports");
        System.out.println("6. Import/Export Data");
        System.out.println("7. Backup & System Tools");
        System.out.println("0. Exit");
    }
    
    // Enhanced switch statement demonstrating comprehensive menu handling
    private void handleMenuChoice(int choice) {
        switch (choice) {
            case 1 -> handleStudentManagement();
            case 2 -> handleCourseManagement();  
            case 3 -> handleEnrollmentManagement();
            case 4 -> handleGradeManagement();
            case 5 -> handleTranscriptReports();
            case 6 -> handleImportExport();
            case 7 -> handleBackupAndTools();
            case 0 -> {
                menuHelper.displayInfo("Thank you for using CCRM. Goodbye!");
                running = false;
            }
            default -> menuHelper.displayError("Invalid choice. Please try again.");
        }
    }
    
    // Student Management Menu (demonstrates nested switch)
    private void handleStudentManagement() {
        while (true) {
            menuHelper.displaySubHeader("Student Management");
            System.out.println("1. Add New Student");
            System.out.println("2. View All Students");
            System.out.println("3. Search Students");
            System.out.println("4. Update Student");
            System.out.println("5. Student Profile & Transcript");
            System.out.println("6. Deactivate Student");
            System.out.println("0. Back to Main Menu");
            
            int choice = menuHelper.getMenuChoice(6);
            
            switch (choice) {
                case 1 -> addNewStudent();
                case 2 -> viewAllStudents();
                case 3 -> searchStudents();
                case 4 -> updateStudent();
                case 5 -> viewStudentProfile();
                case 6 -> deactivateStudent();
                case 0 -> { return; }
                default -> menuHelper.displayError("Invalid choice. Please try again.");
            }
        }
    }
    
    private void addNewStudent() {
        menuHelper.displaySubHeader("Add New Student");
        
        try {
            String regNo = menuHelper.getStringInput("Registration Number", true);
            String fullName = menuHelper.getStringInput("Full Name", true);
            String email = menuHelper.getStringInput("Email", false);
            
            Student student = studentService.createStudent(regNo, fullName, email);
            menuHelper.displaySuccess("Student created successfully: " + student.getFullName() + " (" + student.getId() + ")");
            
        } catch (Exception e) {
            menuHelper.displayError("Failed to create student: " + e.getMessage());
        }
        
        menuHelper.pauseForUser();
    }
    
    private void viewAllStudents() {
        menuHelper.displaySubHeader("All Students");
        List<Student> students = studentService.getAllStudents();
        menuHelper.displayStudentList(students);
        
        System.out.println("Total Students: " + students.size());
        System.out.println("Active Students: " + studentService.getActiveStudentCount());
        
        menuHelper.pauseForUser();
    }
    
    private void searchStudents() {
        menuHelper.displaySubHeader("Search Students");
        
        String searchTerm = menuHelper.getStringInput("Enter search term (name, reg no, or email)", false);
        List<Student> results = studentService.searchStudents(searchTerm);
        
        System.out.println("\nSearch Results:");
        menuHelper.displayStudentList(results);
        
        menuHelper.pauseForUser();
    }
    
    private void updateStudent() {
        menuHelper.displaySubHeader("Update Student");
        
        String studentId = menuHelper.getStringInput("Student ID", true);
        Optional<Student> studentOpt = studentService.findById(studentId);
        
        if (studentOpt.isEmpty()) {
            menuHelper.displayError("Student not found with ID: " + studentId);
            menuHelper.pauseForUser();
            return;
        }
        
        Student student = studentOpt.get();
        System.out.println("\nCurrent Information:");
        System.out.println(student.getFullProfile());
        
        String newName = menuHelper.getStringInput("New Full Name (or press Enter to keep current)", false);
        String newEmail = menuHelper.getStringInput("New Email (or press Enter to keep current)", false);
        
        boolean updated = studentService.updateStudent(studentId, newName, newEmail);
        
        if (updated) {
            menuHelper.displaySuccess("Student information updated successfully!");
        } else {
            menuHelper.displayError("Failed to update student information.");
        }
        
        menuHelper.pauseForUser();
    }
    
    private void viewStudentProfile() {
        menuHelper.displaySubHeader("Student Profile & Transcript");
        
        String studentId = menuHelper.getStringInput("Student ID", true);
        Optional<Student> studentOpt = studentService.findById(studentId);
        
        if (studentOpt.isEmpty()) {
            menuHelper.displayError("Student not found with ID: " + studentId);
            menuHelper.pauseForUser();
            return;
        }
        
        try {
            String transcript = transcriptService.generateTranscript(studentId);
            System.out.println("\n" + transcript);
        } catch (Exception e) {
            menuHelper.displayError("Failed to generate transcript: " + e.getMessage());
        }
        
        menuHelper.pauseForUser();
    }
    
    private void deactivateStudent() {
        menuHelper.displaySubHeader("Deactivate Student");
        
        String studentId = menuHelper.getStringInput("Student ID", true);
        Optional<Student> studentOpt = studentService.findById(studentId);
        
        if (studentOpt.isEmpty()) {
            menuHelper.displayError("Student not found with ID: " + studentId);
            menuHelper.pauseForUser();
            return;
        }
        
        Student student = studentOpt.get();
        System.out.println("\nStudent to deactivate: " + student.getFullName());
        
        boolean confirm = menuHelper.getYesNoInput("Are you sure you want to deactivate this student?");
        
        if (confirm) {
            boolean deactivated = studentService.deactivateStudent(studentId);
            if (deactivated) {
                menuHelper.displaySuccess("Student deactivated successfully.");
            } else {
                menuHelper.displayError("Failed to deactivate student.");
            }
        } else {
            menuHelper.displayInfo("Operation cancelled.");
        }
        
        menuHelper.pauseForUser();
    }
    
    // Continue with remaining menu implementations...
    private void handleCourseManagement() {
        while (true) {
            menuHelper.displaySubHeader("Course Management");
            System.out.println("1. Add New Course");
            System.out.println("2. View All Courses");
            System.out.println("3. Search/Filter Courses");
            System.out.println("4. Update Course");
            System.out.println("5. Course Statistics");
            System.out.println("0. Back to Main Menu");
            
            int choice = menuHelper.getMenuChoice(5);
            
            switch (choice) {
                case 1 -> addNewCourse();
                case 2 -> viewAllCourses(); 
                case 3 -> searchCourses();
                case 4 -> updateCourse();
                case 5 -> viewCourseStatistics();
                case 0 -> { return; }
                default -> menuHelper.displayError("Invalid choice. Please try again.");
            }
        }
    }
    
    private void addNewCourse() {
        menuHelper.displaySubHeader("Add New Course");
        
        try {
            String code = menuHelper.getStringInput("Course Code", true);
            String title = menuHelper.getStringInput("Course Title", true);
            int credits = menuHelper.getIntInput("Credits", 1, 6);
            String department = menuHelper.getStringInput("Department", true);
            Semester semester = menuHelper.getSemesterInput("Select Semester");
            int maxEnrollment = menuHelper.getIntInput("Maximum Enrollment", 1, 200);
            
            Course course = courseService.createCourse(new Course.Builder(code, title)
                .credits(credits)
                .department(department)
                .semester(semester)
                .maxEnrollment(maxEnrollment));
                
            menuHelper.displaySuccess("Course created successfully: " + course.getCode() + " - " + course.getTitle());
            
        } catch (Exception e) {
            menuHelper.displayError("Failed to create course: " + e.getMessage());
        }
        
        menuHelper.pauseForUser();
    }
    
    private void viewAllCourses() {
        menuHelper.displaySubHeader("All Courses");
        
        List<Course> courses = courseService.getAllCourses();
        menuHelper.displayCourseList(courses);
        
        System.out.println("Total Courses: " + courses.size());
        System.out.println("Active Courses: " + courseService.getActiveCourseCount());
        
        menuHelper.pauseForUser();
    }
    
    private void searchCourses() {
        menuHelper.displaySubHeader("Search/Filter Courses");
        
        System.out.println("1. Search by keyword");
        System.out.println("2. Filter by department");
        System.out.println("3. Filter by semester");
        System.out.println("4. Filter by credits");
        
        int filterChoice = menuHelper.getMenuChoice(4);
        List<Course> results = new ArrayList<>();
        
        switch (filterChoice) {
            case 1 -> {
                String keyword = menuHelper.getStringInput("Enter search keyword", false);
                results = courseService.searchCourses(keyword);
            }
            case 2 -> {
                String department = menuHelper.getStringInput("Department name", true);
                results = courseService.filterByDepartment(department);
            }
            case 3 -> {
                Semester semester = menuHelper.getSemesterInput("Select Semester");
                results = courseService.filterBySemester(semester);
            }
            case 4 -> {
                int minCredits = menuHelper.getIntInput("Minimum credits", 1, 6);
                int maxCredits = menuHelper.getIntInput("Maximum credits", minCredits, 6);
                results = courseService.filterByCredits(minCredits, maxCredits);
            }
            default -> {
                menuHelper.displayError("Invalid choice.");
                menuHelper.pauseForUser();
                return;
            }
        }
        
        System.out.println("\nSearch Results:");
        menuHelper.displayCourseList(results);
        
        menuHelper.pauseForUser();
    }
    
    private void updateCourse() {
        menuHelper.displaySubHeader("Update Course");
        
        String courseCode = menuHelper.getStringInput("Course Code", true);
        Optional<Course> courseOpt = courseService.findByCode(courseCode);
        
        if (courseOpt.isEmpty()) {
            menuHelper.displayError("Course not found with code: " + courseCode);
            menuHelper.pauseForUser();
            return;
        }
        
        Course course = courseOpt.get();
        System.out.println("\nCurrent Information: " + course);
        
        String newTitle = menuHelper.getStringInput("New Title (or press Enter to keep current)", false);
        String creditsStr = menuHelper.getStringInput("New Credits (or press Enter to keep current)", false);
        String instructorId = menuHelper.getStringInput("Instructor ID (or press Enter to keep current)", false);
        
        Integer newCredits = null;
        if (creditsStr != null && !creditsStr.isEmpty()) {
            try {
                newCredits = Integer.parseInt(creditsStr);
            } catch (NumberFormatException e) {
                menuHelper.displayError("Invalid credits value.");
                menuHelper.pauseForUser();
                return;
            }
        }
        
        boolean updated = courseService.updateCourse(courseCode, newTitle, newCredits, instructorId);
        
        if (updated) {
            menuHelper.displaySuccess("Course information updated successfully!");
        } else {
            menuHelper.displayError("Failed to update course information.");
        }
        
        menuHelper.pauseForUser();
    }
    
    private void viewCourseStatistics() {
        menuHelper.displaySubHeader("Course Statistics");
        
        Map<String, Object> stats = courseService.getCourseStatistics();
        
        System.out.println("Course Statistics:");
        System.out.println("==================");
        System.out.println("Total Courses: " + stats.get("totalCourses"));
        System.out.println("Active Courses: " + stats.get("activeCourses"));
        System.out.println("Total Capacity: " + stats.get("totalCapacity"));
        System.out.println("Current Enrollment: " + stats.get("currentEnrollment"));
        System.out.println("Average Enrollment: " + String.format("%.1f%%", stats.get("averageEnrollmentPercentage")));
        
        @SuppressWarnings("unchecked")
        Map<String, Integer> deptStats = (Map<String, Integer>) stats.get("departmentDistribution");
        System.out.println("\nCourses by Department:");
        deptStats.forEach((dept, count) -> System.out.println("  " + dept + ": " + count));
        
        menuHelper.pauseForUser();
    }
    
    // Complete implementation of remaining menus
    private void handleEnrollmentManagement() {
        while (true) {
            menuHelper.displaySubHeader("Enrollment Management");
            System.out.println("1. Enroll Student in Course");
            System.out.println("2. Drop Student from Course");
            System.out.println("3. View Student Enrollments");
            System.out.println("4. View Course Enrollments");
            System.out.println("5. Course Availability");
            System.out.println("0. Back to Main Menu");
            
            int choice = menuHelper.getMenuChoice(5);
            
            switch (choice) {
                case 1 -> enrollStudentInCourse();
                case 2 -> dropStudentFromCourse();
                case 3 -> viewStudentEnrollments();
                case 4 -> viewCourseEnrollments();
                case 5 -> viewCourseAvailability();
                case 0 -> { return; }
                default -> menuHelper.displayError("Invalid choice. Please try again.");
            }
        }
    }
    
    private void enrollStudentInCourse() {
        menuHelper.displaySubHeader("Enroll Student in Course");
        
        try {
            String studentId = menuHelper.getStringInput("Student ID", true);
            String courseCode = menuHelper.getStringInput("Course Code", true);
            
            // Validate student exists
            Optional<Student> studentOpt = studentService.findById(studentId);
            if (studentOpt.isEmpty()) {
                menuHelper.displayError("Student not found with ID: " + studentId);
                menuHelper.pauseForUser();
                return;
            }
            
            // Validate course exists
            Optional<Course> courseOpt = courseService.findByCode(courseCode);
            if (courseOpt.isEmpty()) {
                menuHelper.displayError("Course not found with code: " + courseCode);
                menuHelper.pauseForUser();
                return;
            }
            
            Course course = courseOpt.get();
            System.out.println("Enrolling: " + studentOpt.get().getFullName());
            System.out.println("In Course: " + course.getCode() + " - " + course.getTitle());
            System.out.println("Available Slots: " + course.getAvailableSlots() + "/" + course.getMaxEnrollment());
            
            boolean confirm = menuHelper.getYesNoInput("Confirm enrollment?");
            
            if (confirm) {
                enrollmentService.enrollStudent(studentId, courseCode);
                menuHelper.displaySuccess("Student enrolled successfully!");
            } else {
                menuHelper.displayInfo("Enrollment cancelled.");
            }
            
        } catch (Exception e) {
            menuHelper.displayError("Enrollment failed: " + e.getMessage());
        }
        
        menuHelper.pauseForUser();
    }
    
    private void dropStudentFromCourse() {
        menuHelper.displaySubHeader("Drop Student from Course");
        
        try {
            String studentId = menuHelper.getStringInput("Student ID", true);
            String courseCode = menuHelper.getStringInput("Course Code", true);
            
            boolean confirm = menuHelper.getYesNoInput("Confirm dropping student from course?");
            
            if (confirm) {
                boolean dropped = enrollmentService.unenrollStudent(studentId, courseCode);
                if (dropped) {
                    menuHelper.displaySuccess("Student dropped from course successfully!");
                } else {
                    menuHelper.displayError("Failed to drop student - enrollment may not exist.");
                }
            } else {
                menuHelper.displayInfo("Drop operation cancelled.");
            }
            
        } catch (Exception e) {
            menuHelper.displayError("Drop operation failed: " + e.getMessage());
        }
        
        menuHelper.pauseForUser();
    }
    
    private void viewStudentEnrollments() {
        menuHelper.displaySubHeader("Student Enrollments");
        
        String studentId = menuHelper.getStringInput("Student ID", true);
        Optional<Student> studentOpt = studentService.findById(studentId);
        
        if (studentOpt.isEmpty()) {
            menuHelper.displayError("Student not found with ID: " + studentId);
            menuHelper.pauseForUser();
            return;
        }
        
        List<Enrollment> enrollments = enrollmentService.getStudentEnrollments(studentId);
        Student student = studentOpt.get();
        
        System.out.println("\nEnrollments for: " + student.getFullName() + " (" + student.getRegNo() + ")");
        System.out.println("-".repeat(80));
        
        if (enrollments.isEmpty()) {
            System.out.println("No enrollments found.");
        } else {
            System.out.printf("%-12s %-35s %-8s %-8s %-12s%n", 
                "Course", "Title", "Credits", "Grade", "Status");
            System.out.println("-".repeat(80));
            
            for (Enrollment enrollment : enrollments) {
                Optional<Course> courseOpt = courseService.findByCode(enrollment.getCourseCode());
                if (courseOpt.isPresent()) {
                    Course course = courseOpt.get();
                    String grade = enrollment.isGraded() ? enrollment.getGrade().getLetter() : "N/A";
                    
                    System.out.printf("%-12s %-35s %-8d %-8s %-12s%n",
                        course.getCode(),
                        course.getTitle().length() > 35 ? course.getTitle().substring(0, 32) + "..." : course.getTitle(),
                        course.getCredits(),
                        grade,
                        enrollment.getStatus()
                    );
                }
            }
        }
        
        menuHelper.pauseForUser();
    }
    
    private void viewCourseEnrollments() {
        menuHelper.displaySubHeader("Course Enrollments");
        
        String courseCode = menuHelper.getStringInput("Course Code", true);
        Optional<Course> courseOpt = courseService.findByCode(courseCode);
        
        if (courseOpt.isEmpty()) {
            menuHelper.displayError("Course not found with code: " + courseCode);
            menuHelper.pauseForUser();
            return;
        }
        
        List<Enrollment> enrollments = enrollmentService.getCourseEnrollments(courseCode);
        Course course = courseOpt.get();
        
        System.out.println("\nEnrollments for: " + course.getCode() + " - " + course.getTitle());
        System.out.println("Capacity: " + course.getCurrentEnrollment() + "/" + course.getMaxEnrollment());
        System.out.println("-".repeat(80));
        
        if (enrollments.isEmpty()) {
            System.out.println("No enrollments found.");
        } else {
            System.out.printf("%-12s %-15s %-30s %-8s %-12s%n", 
                "Student ID", "Reg No", "Name", "Grade", "Status");
            System.out.println("-".repeat(80));
            
            for (Enrollment enrollment : enrollments) {
                Optional<Student> studentOpt = studentService.findById(enrollment.getStudentId());
                if (studentOpt.isPresent()) {
                    Student student = studentOpt.get();
                    String grade = enrollment.isGraded() ? enrollment.getGrade().getLetter() : "N/A";
                    
                    System.out.printf("%-12s %-15s %-30s %-8s %-12s%n",
                        student.getId(),
                        student.getRegNo(),
                        student.getFullName(),
                        grade,
                        enrollment.getStatus()
                    );
                }
            }
        }
        
        menuHelper.pauseForUser();
    }
    
    private void viewCourseAvailability() {
        menuHelper.displaySubHeader("Course Availability");
        
        List<Course> courses = courseService.getActiveCourses();
        
        System.out.printf("%-10s %-35s %-12s %-12s %-12s%n",
            "Code", "Title", "Enrolled", "Capacity", "Available");
        System.out.println("-".repeat(85));
        
        for (Course course : courses) {
            System.out.printf("%-10s %-35s %-12d %-12d %-12d%n",
                course.getCode(),
                course.getTitle().length() > 35 ? course.getTitle().substring(0, 32) + "..." : course.getTitle(),
                course.getCurrentEnrollment(),
                course.getMaxEnrollment(),
                course.getAvailableSlots()
            );
        }
        
        menuHelper.pauseForUser();
    }
    
    private void handleGradeManagement() {
        while (true) {
            menuHelper.displaySubHeader("Grade Management");
            System.out.println("1. Record Grade by Marks");
            System.out.println("2. Record Grade by Letter");
            System.out.println("3. View Student Grades");
            System.out.println("4. Grade Distribution Report");
            System.out.println("5. Course Pass Rates");
            System.out.println("0. Back to Main Menu");
            
            int choice = menuHelper.getMenuChoice(5);
            
            switch (choice) {
                case 1 -> recordGradeByMarks();
                case 2 -> recordGradeByLetter();
                case 3 -> viewStudentGrades();
                case 4 -> viewGradeDistribution();
                case 5 -> viewCoursePassRates();
                case 0 -> { return; }
                default -> menuHelper.displayError("Invalid choice. Please try again.");
            }
        }
    }
    
    private void recordGradeByMarks() {
        menuHelper.displaySubHeader("Record Grade by Marks");
        
        try {
            String studentId = menuHelper.getStringInput("Student ID", true);
            String courseCode = menuHelper.getStringInput("Course Code", true);
            int marks = menuHelper.getIntInput("Marks", 0, 100);
            
            enrollmentService.recordGrade(studentId, courseCode, marks);
            Grade grade = Grade.fromMarks(marks);
            menuHelper.displaySuccess("Grade recorded: " + marks + " marks = " + grade.getLetter() + " (" + grade.getDescription() + ")");
            
        } catch (Exception e) {
            menuHelper.displayError("Grade recording failed: " + e.getMessage());
        }
        
        menuHelper.pauseForUser();
    }
    
    private void recordGradeByLetter() {
        menuHelper.displaySubHeader("Record Grade by Letter");
        
        try {
            String studentId = menuHelper.getStringInput("Student ID", true);
            String courseCode = menuHelper.getStringInput("Course Code", true);
            Grade grade = menuHelper.getGradeInput("Select Grade");
            
            enrollmentService.recordGrade(studentId, courseCode, grade);
            menuHelper.displaySuccess("Grade recorded: " + grade.getLetter() + " (" + grade.getDescription() + ")");
            
        } catch (Exception e) {
            menuHelper.displayError("Grade recording failed: " + e.getMessage());
        }
        
        menuHelper.pauseForUser();
    }
    
    private void viewStudentGrades() {
        menuHelper.displaySubHeader("Student Grades");
        
        String studentId = menuHelper.getStringInput("Student ID", true);
        Optional<Student> studentOpt = studentService.findById(studentId);
        
        if (studentOpt.isEmpty()) {
            menuHelper.displayError("Student not found with ID: " + studentId);
            menuHelper.pauseForUser();
            return;
        }
        
        List<Enrollment> enrollments = enrollmentService.getStudentEnrollments(studentId)
            .stream()
            .filter(Enrollment::isGraded)
            .collect(Collectors.toList());
        
        Student student = studentOpt.get();
        System.out.println("\nGrades for: " + student.getFullName() + " (GPA: " + String.format("%.2f", student.getGpa()) + ")");
        System.out.println("-".repeat(80));
        
        if (enrollments.isEmpty()) {
            System.out.println("No grades recorded yet.");
        } else {
            System.out.printf("%-12s %-35s %-8s %-8s %-8s%n", 
                "Course", "Title", "Credits", "Grade", "Points");
            System.out.println("-".repeat(80));
            
            for (Enrollment enrollment : enrollments) {
                Optional<Course> courseOpt = courseService.findByCode(enrollment.getCourseCode());
                if (courseOpt.isPresent()) {
                    Course course = courseOpt.get();
                    Grade grade = enrollment.getGrade();
                    
                    System.out.printf("%-12s %-35s %-8d %-8s %-8.1f%n",
                        course.getCode(),
                        course.getTitle().length() > 35 ? course.getTitle().substring(0, 32) + "..." : course.getTitle(),
                        course.getCredits(),
                        grade.getLetter(),
                        grade.getGradePoint()
                    );
                }
            }
        }
        
        menuHelper.pauseForUser();
    }
    
    private void viewGradeDistribution() {
        menuHelper.displaySubHeader("Grade Distribution Report");
        
        Map<Grade, Long> distribution = enrollmentService.getGradeDistribution();
        
        System.out.println("Grade Distribution:");
        System.out.println("==================");
        
        long totalGraded = distribution.values().stream().mapToLong(Long::longValue).sum();
        
        if (totalGraded == 0) {
            System.out.println("No grades recorded yet.");
        } else {
            for (Grade grade : Grade.values()) {
                long count = distribution.getOrDefault(grade, 0L);
                double percentage = (double) count / totalGraded * 100;
                
                System.out.printf("Grade %s (%s): %d (%.1f%%)%n", 
                    grade.getLetter(), grade.getDescription(), count, percentage);
            }
            
            System.out.println("\nTotal graded enrollments: " + totalGraded);
            System.out.println("Overall pass rate: " + String.format("%.1f%%", enrollmentService.getOverallPassRate()));
        }
        
        menuHelper.pauseForUser();
    }
    
    private void viewCoursePassRates() {
        menuHelper.displaySubHeader("Course Pass Rates");
        
        Map<String, Double> passRates = enrollmentService.getCoursePassRates();
        
        if (passRates.isEmpty()) {
            System.out.println("No course grades available for analysis.");
        } else {
            System.out.printf("%-12s %-35s %-12s%n", "Course", "Title", "Pass Rate");
            System.out.println("-".repeat(65));
            
            passRates.entrySet().stream()
                .sorted(Map.Entry.<String, Double>comparingByValue().reversed())
                .forEach(entry -> {
                    String courseCode = entry.getKey();
                    Double passRate = entry.getValue();
                    
                    Optional<Course> courseOpt = courseService.findByCode(courseCode);
                    String title = courseOpt.map(Course::getTitle).orElse("Unknown");
                    
                    System.out.printf("%-12s %-35s %-12s%n",
                        courseCode,
                        title.length() > 35 ? title.substring(0, 32) + "..." : title,
                        String.format("%.1f%%", passRate)
                    );
                });
        }
        
        menuHelper.pauseForUser();
    }
    
    private void handleTranscriptReports() {
        while (true) {
            menuHelper.displaySubHeader("Transcript & Reports");
            System.out.println("1. Generate Student Transcript");
            System.out.println("2. Generate Grade Report");
            System.out.println("3. Top Students Report");
            System.out.println("4. Academic Standing Summary");
            System.out.println("5. Enrollment Statistics");
            System.out.println("0. Back to Main Menu");
            
            int choice = menuHelper.getMenuChoice(5);
            
            switch (choice) {
                case 1 -> generateStudentTranscript();
                case 2 -> generateGradeReport();
                case 3 -> generateTopStudentsReport();
                case 4 -> generateAcademicStandingSummary();
                case 5 -> generateEnrollmentStatistics();
                case 0 -> { return; }
                default -> menuHelper.displayError("Invalid choice. Please try again.");
            }
        }
    }
    
    private void generateStudentTranscript() {
        menuHelper.displaySubHeader("Generate Student Transcript");
        
        String studentId = menuHelper.getStringInput("Student ID", true);
        
        try {
            String transcript = transcriptService.generateTranscript(studentId);
            System.out.println("\n" + transcript);
        } catch (Exception e) {
            menuHelper.displayError("Failed to generate transcript: " + e.getMessage());
        }
        
        menuHelper.pauseForUser();
    }
    
    private void generateGradeReport() {
        menuHelper.displaySubHeader("Generate Grade Report");
        
        String studentId = menuHelper.getStringInput("Student ID", true);
        Semester semester = menuHelper.getSemesterInput("Select Semester");
        
        try {
            String report = transcriptService.generateGradeReport(studentId, semester);
            System.out.println("\n" + report);
        } catch (Exception e) {
            menuHelper.displayError("Failed to generate grade report: " + e.getMessage());
        }
        
        menuHelper.pauseForUser();
    }
    
    private void generateTopStudentsReport() {
        menuHelper.displaySubHeader("Top Students Report");
        
        int limit = menuHelper.getIntInput("Number of top students to show", 1, 50);
        
        List<Student> topStudents = studentService.getTopStudents(limit);
        
        System.out.println("\nTop " + limit + " Students by GPA:");
        System.out.println("=".repeat(50));
        
        if (topStudents.isEmpty()) {
            System.out.println("No students with recorded GPAs found.");
        } else {
            System.out.printf("%-4s %-12s %-15s %-25s %-8s%n", 
                "Rank", "ID", "Reg No", "Name", "GPA");
            System.out.println("-".repeat(70));
            
            for (int i = 0; i < topStudents.size(); i++) {
                Student student = topStudents.get(i);
                System.out.printf("%-4d %-12s %-15s %-25s %-8.2f%n",
                    (i + 1),
                    student.getId(),
                    student.getRegNo(),
                    student.getFullName(),
                    student.getGpa()
                );
            }
        }
        
        menuHelper.pauseForUser();
    }
    
    private void generateAcademicStandingSummary() {
        menuHelper.displaySubHeader("Academic Standing Summary");
        
        Map<String, Long> standingStats = studentService.getStudentsByAcademicStanding();
        
        System.out.println("Academic Standing Distribution:");
        System.out.println("==============================");
        
        long totalStudents = standingStats.values().stream().mapToLong(Long::longValue).sum();
        
        if (totalStudents == 0) {
            System.out.println("No students with academic records found.");
        } else {
            standingStats.entrySet().stream()
                .sorted(Map.Entry.<String, Long>comparingByValue().reversed())
                .forEach(entry -> {
                    String standing = entry.getKey();
                    Long count = entry.getValue();
                    double percentage = (double) count / totalStudents * 100;
                    
                    System.out.printf("%-15s: %3d students (%.1f%%)%n", 
                        standing, count, percentage);
                });
            
            System.out.println("\nTotal students: " + totalStudents);
            System.out.println("Average GPA: " + String.format("%.2f", studentService.calculateAverageGpa()));
        }
        
        menuHelper.pauseForUser();
    }
    
    private void generateEnrollmentStatistics() {
        menuHelper.displaySubHeader("Enrollment Statistics");
        
        Map<String, Object> enrollmentStats = enrollmentService.getEnrollmentStatistics();
        Map<String, Object> studentStats = studentService.getStudentStatistics();
        Map<String, Object> courseStats = courseService.getCourseStatistics();
        
        System.out.println("System Statistics Summary:");
        System.out.println("=========================");
        System.out.println("Students: " + studentStats.get("totalStudents") + " total, " + 
            studentStats.get("activeStudents") + " active");
        System.out.println("Courses: " + courseStats.get("totalCourses") + " total, " + 
            courseStats.get("activeCourses") + " active");
        System.out.println("Enrollments: " + enrollmentStats.get("totalEnrollments") + " total, " + 
            enrollmentStats.get("activeEnrollments") + " active, " + 
            enrollmentStats.get("completedEnrollments") + " completed");
        System.out.println("Overall Pass Rate: " + String.format("%.1f%%", (Double) enrollmentStats.get("overallPassRate")));
        System.out.println("Average GPA: " + String.format("%.2f", (Double) studentStats.get("averageGpa")));
        
        menuHelper.pauseForUser();
    }
    
    private void handleImportExport() {
        while (true) {
            menuHelper.displaySubHeader("Import/Export Data");
            System.out.println("1. Export Students to CSV");
            System.out.println("2. Export Courses to CSV");
            System.out.println("3. Export Enrollments to CSV");
            System.out.println("4. Export All Data");
            System.out.println("5. Import Students from CSV");
            System.out.println("6. Import Courses from CSV");
            System.out.println("7. Restore from Backup");
            System.out.println("0. Back to Main Menu");
            
            int choice = menuHelper.getMenuChoice(7);
            
            switch (choice) {
                case 1 -> exportStudents();
                case 2 -> exportCourses();
                case 3 -> exportEnrollments();
                case 4 -> exportAllData();
                case 5 -> importStudents();
                case 6 -> importCourses();
                case 7 -> restoreFromBackup();
                case 0 -> { return; }
                default -> menuHelper.displayError("Invalid choice. Please try again.");
            }
        }
    }
    
    private void exportStudents() {
        menuHelper.displaySubHeader("Export Students to CSV");
        
        try {
            String fileName = menuHelper.getStringInput("File name (without .csv extension)", true);
            Path filePath = Paths.get("data", fileName + ".csv");
            
            importExportService.exportStudents(filePath);
            
            menuHelper.displaySuccess("Students exported to: " + filePath.toAbsolutePath());
            System.out.println("Exported " + studentService.getTotalStudentCount() + " students.");
            
        } catch (Exception e) {
            menuHelper.displayError("Export failed: " + e.getMessage());
        }
        
        menuHelper.pauseForUser();
    }
    
    private void exportCourses() {
        menuHelper.displaySubHeader("Export Courses to CSV");
        
        try {
            String fileName = menuHelper.getStringInput("File name (without .csv extension)", true);
            Path filePath = Paths.get("data", fileName + ".csv");
            
            importExportService.exportCourses(filePath);
            
            menuHelper.displaySuccess("Courses exported to: " + filePath.toAbsolutePath());
            System.out.println("Exported " + courseService.getTotalCourseCount() + " courses.");
            
        } catch (Exception e) {
            menuHelper.displayError("Export failed: " + e.getMessage());
        }
        
        menuHelper.pauseForUser();
    }
    
    private void exportEnrollments() {
        menuHelper.displaySubHeader("Export Enrollments to CSV");
        
        try {
            String fileName = menuHelper.getStringInput("File name (without .csv extension)", true);
            Path filePath = Paths.get("data", fileName + ".csv");
            
            importExportService.exportEnrollments(filePath);
            
            menuHelper.displaySuccess("Enrollments exported to: " + filePath.toAbsolutePath());
            System.out.println("Exported " + enrollmentService.getActiveEnrollmentCount() + " enrollments.");
            
        } catch (Exception e) {
            menuHelper.displayError("Export failed: " + e.getMessage());
        }
        
        menuHelper.pauseForUser();
    }
    
    private void exportAllData() {
        menuHelper.displaySubHeader("Export All Data");
        
        try {
            Path exportDir = Paths.get("data", "exports");
            
            importExportService.exportAllData(exportDir);
            
            menuHelper.displaySuccess("All data exported to: " + exportDir.toAbsolutePath());
            System.out.println("Check the export_summary.txt file for details.");
            
        } catch (Exception e) {
            menuHelper.displayError("Export failed: " + e.getMessage());
        }
        
        menuHelper.pauseForUser();
    }
    
    private void importStudents() {
        menuHelper.displaySubHeader("Import Students from CSV");
        
        try {
            String fileName = menuHelper.getStringInput("CSV file path", true);
            Path filePath = Paths.get(fileName);
            
            if (!importExportService.isValidCSVFile(filePath)) {
                menuHelper.displayError("Invalid or inaccessible CSV file: " + fileName);
                menuHelper.pauseForUser();
                return;
            }
            
            boolean confirm = menuHelper.getYesNoInput("This will import students from " + fileName + ". Continue?");
            
            if (confirm) {
                int imported = importExportService.importStudents(filePath);
                menuHelper.displaySuccess("Imported " + imported + " students successfully.");
            } else {
                menuHelper.displayInfo("Import cancelled.");
            }
            
        } catch (Exception e) {
            menuHelper.displayError("Import failed: " + e.getMessage());
        }
        
        menuHelper.pauseForUser();
    }
    
    private void importCourses() {
        menuHelper.displaySubHeader("Import Courses from CSV");
        
        try {
            String fileName = menuHelper.getStringInput("CSV file path", true);
            Path filePath = Paths.get(fileName);
            
            if (!importExportService.isValidCSVFile(filePath)) {
                menuHelper.displayError("Invalid or inaccessible CSV file: " + fileName);
                menuHelper.pauseForUser();
                return;
            }
            
            boolean confirm = menuHelper.getYesNoInput("This will import courses from " + fileName + ". Continue?");
            
            if (confirm) {
                int imported = importExportService.importCourses(filePath);
                menuHelper.displaySuccess("Imported " + imported + " courses successfully.");
            } else {
                menuHelper.displayInfo("Import cancelled.");
            }
            
        } catch (Exception e) {
            menuHelper.displayError("Import failed: " + e.getMessage());
        }
        
        menuHelper.pauseForUser();
    }
    
    private void restoreFromBackup() {
        menuHelper.displaySubHeader("Restore from Backup");
        
        try {
            List<Path> backups = backupService.listBackups();
            
            if (backups.isEmpty()) {
                menuHelper.displayError("No backups available for restore.");
                menuHelper.pauseForUser();
                return;
            }
            
            System.out.println("Available backups:");
            for (int i = 0; i < backups.size(); i++) {
                System.out.println((i + 1) + ". " + backups.get(i).getFileName());
            }
            
            int choice = menuHelper.getIntInput("Select backup to restore", 1, backups.size());
            Path selectedBackup = backups.get(choice - 1);
            
            menuHelper.displayWarning("This will restore data from backup and may overwrite existing data.");
            boolean confirm = menuHelper.getYesNoInput("Are you sure you want to restore from " + 
                selectedBackup.getFileName() + "?");
            
            if (confirm) {
                boolean restored = backupService.restoreFromBackup(selectedBackup);
                if (restored) {
                    menuHelper.displaySuccess("Data restored successfully from backup!");
                } else {
                    menuHelper.displayError("Restore operation completed with issues. Check logs for details.");
                }
            } else {
                menuHelper.displayInfo("Restore operation cancelled.");
            }
            
        } catch (Exception e) {
            menuHelper.displayError("Restore failed: " + e.getMessage());
        }
        
        menuHelper.pauseForUser();
    }
    
    private void handleBackupAndTools() {
        while (true) {
            menuHelper.displaySubHeader("Backup & System Tools");
            System.out.println("1. Create Backup");
            System.out.println("2. List Backups");
            System.out.println("3. Backup Statistics");
            System.out.println("4. Directory Structure");
            System.out.println("5. System Information");
            System.out.println("0. Back to Main Menu");
            
            int choice = menuHelper.getMenuChoice(5);
            
            switch (choice) {
                case 1 -> createBackup();
                case 2 -> listBackups();
                case 3 -> showBackupStatistics();
                case 4 -> showDirectoryStructure();
                case 5 -> displaySystemInfo();
                case 0 -> { return; }
                default -> menuHelper.displayError("Invalid choice. Please try again.");
            }
        }
    }
    
    private void createBackup() {
        menuHelper.displaySubHeader("Create Backup");
        
        try {
            System.out.println("Creating backup...");
            Path backupPath = backupService.createBackup();
            menuHelper.displaySuccess("Backup created at: " + backupPath.toAbsolutePath());
            
            long size = backupService.calculateDirectorySize(backupPath);
            System.out.println("Backup size: " + formatFileSize(size));
            
        } catch (Exception e) {
            menuHelper.displayError("Backup creation failed: " + e.getMessage());
        }
        
        menuHelper.pauseForUser();
    }
    
    private void listBackups() {
        menuHelper.displaySubHeader("Available Backups");
        
        try {
            List<Path> backups = backupService.listBackups();
            
            if (backups.isEmpty()) {
                System.out.println("No backups found.");
            } else {
                System.out.println("\nFound " + backups.size() + " backup(s):");
                for (int i = 0; i < backups.size(); i++) {
                    Path backup = backups.get(i);
                    long size = backupService.calculateDirectorySize(backup);
                    System.out.println((i + 1) + ". " + backup.getFileName() + 
                        " (" + formatFileSize(size) + ")");
                }
            }
        } catch (Exception e) {
            menuHelper.displayError("Failed to list backups: " + e.getMessage());
        }
        
        menuHelper.pauseForUser();
    }
    
    private void showBackupStatistics() {
        menuHelper.displaySubHeader("Backup Statistics");
        
        try {
            Map<String, Object> stats = backupService.getBackupStatistics();
            
            System.out.println("Backup Statistics:");
            System.out.println("==================");
            System.out.println("Total Backups: " + stats.get("totalBackups"));
            System.out.println("Backup Location: " + stats.get("backupLocation"));
            System.out.println("Latest Backup: " + stats.get("latestBackup"));
            System.out.println("Latest Backup Size: " + formatFileSize((Long) stats.get("latestBackupSize")));
            System.out.println("Total Backup Size: " + formatFileSize((Long) stats.get("totalBackupSize")));
            
        } catch (Exception e) {
            menuHelper.displayError("Failed to get backup statistics: " + e.getMessage());
        }
        
        menuHelper.pauseForUser();
    }
    
    private void showDirectoryStructure() {
        menuHelper.displaySubHeader("Directory Structure (Recursive)");
        
        try {
            System.out.println("Data Directory Structure:");
            backupService.printDirectoryStructure(Paths.get("data"));
            
            System.out.println("\nBackup Directory Structure:");
            backupService.printDirectoryStructure(Paths.get("backups"));
            
        } catch (Exception e) {
            menuHelper.displayError("Failed to show directory structure: " + e.getMessage());
        }
        
        menuHelper.pauseForUser();
    }
    
    private void displaySystemInfo() {
        menuHelper.displaySubHeader("Java Platform Information");
        
        System.out.println("Java Platform Evolution:");
        System.out.println("• 1995: Java 1.0 - Original release");
        System.out.println("• 2004: Java 5 - Generics, annotations");
        System.out.println("• 2014: Java 8 - Lambda expressions, Stream API");
        System.out.println("• 2017: Java 9 - Module system");
        System.out.println("• 2021: Java 17 - LTS with sealed classes");
        System.out.println("• 2023: Java 21 - Latest LTS");
        
        System.out.println("\nJava Editions:");
        System.out.println("• Java SE (Standard Edition): Desktop and server applications");
        System.out.println("• Java ME (Micro Edition): Mobile and embedded devices"); 
        System.out.println("• Java EE (Enterprise Edition): Large-scale enterprise applications");
        
        System.out.println("\nJava Architecture:");
        System.out.println("• JDK (Development Kit): Compiler, debugger, and development tools");
        System.out.println("• JRE (Runtime Environment): JVM + standard libraries");
        System.out.println("• JVM (Virtual Machine): Executes Java bytecode");
        
        System.out.println("\nCurrent Environment:");
        System.out.println("• Java Version: " + System.getProperty("java.version"));
        System.out.println("• JVM: " + System.getProperty("java.vm.name"));
        System.out.println("• OS: " + System.getProperty("os.name"));
        System.out.println("• Architecture: " + System.getProperty("os.arch"));
        System.out.println("• Available Processors: " + Runtime.getRuntime().availableProcessors());
        
        menuHelper.pauseForUser();
    }
    
    private String formatFileSize(long bytes) {
        if (bytes < 1024) return bytes + " B";
        if (bytes < 1024 * 1024) return String.format("%.1f KB", bytes / 1024.0);
        if (bytes < 1024 * 1024 * 1024) return String.format("%.1f MB", bytes / (1024.0 * 1024.0));
        return String.format("%.1f GB", bytes / (1024.0 * 1024.0 * 1024.0));
    }
}