package edu.ccrm.domain;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Instructor class extending Person - demonstrates inheritance and polymorphism
 * Contains instructor-specific fields and methods
 */
public class Instructor extends Person {
    private final String employeeId;
    private String department;
    private String title;
    private List<String> assignedCourses;
    private LocalDate hireDate;
    private double salary;
    
    // Constructor calling super constructor
    public Instructor(String id, String employeeId, String fullName, String email, String department) {
        super(id, fullName, email);
        
        if (employeeId == null || employeeId.trim().isEmpty()) {
            throw new IllegalArgumentException("Employee ID cannot be null or empty");
        }
        if (department == null || department.trim().isEmpty()) {
            throw new IllegalArgumentException("Department cannot be null or empty");
        }
        
        this.employeeId = employeeId.trim();
        this.department = department.trim();
        this.title = "Assistant Professor";
        this.assignedCourses = new ArrayList<>();
        this.hireDate = LocalDate.now();
        this.salary = 0.0;
    }
    
    // Instructor-specific getters and setters
    public String getEmployeeId() {
        return employeeId;
    }
    
    public String getDepartment() {
        return department;
    }
    
    public void setDepartment(String department) {
        if (department == null || department.trim().isEmpty()) {
            throw new IllegalArgumentException("Department cannot be null or empty");
        }
        this.department = department.trim();
    }
    
    public String getTitle() {
        return title;
    }
    
    public void setTitle(String title) {
        this.title = title != null ? title.trim() : "Assistant Professor";
    }
    
    public List<String> getAssignedCourses() {
        return Collections.unmodifiableList(assignedCourses);
    }
    
    public LocalDate getHireDate() {
        return hireDate;
    }
    
    public void setHireDate(LocalDate hireDate) {
        this.hireDate = hireDate;
    }
    
    public double getSalary() {
        return salary;
    }
    
    public void setSalary(double salary) {
        if (salary < 0) {
            throw new IllegalArgumentException("Salary cannot be negative");
        }
        this.salary = salary;
    }
    
    // Business logic methods
    public void assignCourse(String courseCode) {
        if (courseCode == null || courseCode.trim().isEmpty()) {
            throw new IllegalArgumentException("Course code cannot be null or empty");
        }
        
        String normalizedCode = courseCode.trim().toUpperCase();
        if (!assignedCourses.contains(normalizedCode)) {
            assignedCourses.add(normalizedCode);
        }
    }
    
    public void unassignCourse(String courseCode) {
        if (courseCode != null) {
            assignedCourses.remove(courseCode.trim().toUpperCase());
        }
    }
    
    public boolean isAssignedToCourse(String courseCode) {
        return courseCode != null && assignedCourses.contains(courseCode.trim().toUpperCase());
    }
    
    public int getWorkload() {
        return assignedCourses.size();
    }
    
    // Implementation of abstract methods from Person
    @Override
    public String getPersonType() {
        return "Instructor";
    }
    
    @Override
    public String getDisplayInfo() {
        StringBuilder info = new StringBuilder();
        info.append("Employee ID: ").append(employeeId).append("\n");
        info.append("Department: ").append(department).append("\n");
        info.append("Title: ").append(title).append("\n");
        info.append("Hire Date: ").append(hireDate).append("\n");
        info.append("Salary: $").append(String.format("%.2f", salary)).append("\n");
        info.append("Assigned Courses (").append(assignedCourses.size()).append("): ");
        
        if (assignedCourses.isEmpty()) {
            info.append("None");
        } else {
            info.append(String.join(", ", assignedCourses));
        }
        
        return info.toString();
    }
    
    // Professional methods
    public String getRank() {
        if (title == null) return "Unranked";
        
        String lowerTitle = title.toLowerCase();
        if (lowerTitle.contains("professor")) return "Professor";
        if (lowerTitle.contains("associate")) return "Associate Professor";
        if (lowerTitle.contains("assistant")) return "Assistant Professor";
        if (lowerTitle.contains("lecturer")) return "Lecturer";
        return "Academic Staff";
    }
    
    public boolean isEligibleForPromotion() {
        LocalDate now = LocalDate.now();
        long yearsOfService = java.time.Period.between(hireDate, now).getYears();
        return yearsOfService >= 3 && getWorkload() >= 2;
    }
}