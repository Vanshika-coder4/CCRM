package edu.ccrm.domain;

import java.time.LocalDate;
import java.util.Objects;

/**
 * Enrollment class representing the relationship between Student and Course
 * Demonstrates composition and business rule enforcement
 */
public class Enrollment {
    private final String enrollmentId;
    private final String studentId;
    private final String courseCode;
    private LocalDate enrollmentDate;
    private Grade grade;
    private int marksObtained;
    private boolean dropped;
    private LocalDate dropDate;
    
    public Enrollment(String enrollmentId, String studentId, String courseCode) {
        if (enrollmentId == null || enrollmentId.trim().isEmpty()) {
            throw new IllegalArgumentException("Enrollment ID cannot be null or empty");
        }
        if (studentId == null || studentId.trim().isEmpty()) {
            throw new IllegalArgumentException("Student ID cannot be null or empty");
        }
        if (courseCode == null || courseCode.trim().isEmpty()) {
            throw new IllegalArgumentException("Course code cannot be null or empty");
        }
        
        this.enrollmentId = enrollmentId.trim();
        this.studentId = studentId.trim();
        this.courseCode = courseCode.trim().toUpperCase();
        this.enrollmentDate = LocalDate.now();
        this.grade = null;
        this.marksObtained = -1; // -1 indicates not graded yet
        this.dropped = false;
        this.dropDate = null;
    }
    
    // Getters
    public String getEnrollmentId() {
        return enrollmentId;
    }
    
    public String getStudentId() {
        return studentId;
    }
    
    public String getCourseCode() {
        return courseCode;
    }
    
    public LocalDate getEnrollmentDate() {
        return enrollmentDate;
    }
    
    public void setEnrollmentDate(LocalDate enrollmentDate) {
        if (enrollmentDate != null && enrollmentDate.isAfter(LocalDate.now())) {
            throw new IllegalArgumentException("Enrollment date cannot be in the future");
        }
        this.enrollmentDate = enrollmentDate;
    }
    
    public Grade getGrade() {
        return grade;
    }
    
    public int getMarksObtained() {
        return marksObtained;
    }
    
    public boolean isDropped() {
        return dropped;
    }
    
    public LocalDate getDropDate() {
        return dropDate;
    }
    
    // Business logic methods
    public void recordGrade(int marks) {
        if (dropped) {
            throw new IllegalStateException("Cannot grade a dropped enrollment");
        }
        if (marks < 0 || marks > 100) {
            throw new IllegalArgumentException("Marks must be between 0 and 100");
        }
        
        this.marksObtained = marks;
        this.grade = Grade.fromMarks(marks);
    }
    
    public void recordGrade(Grade grade) {
        if (dropped) {
            throw new IllegalStateException("Cannot grade a dropped enrollment");
        }
        if (grade == null) {
            throw new IllegalArgumentException("Grade cannot be null");
        }
        
        this.grade = grade;
        // Set marks to middle of grade range for consistency
        this.marksObtained = (grade.getMinMarks() + grade.getMaxMarks()) / 2;
    }
    
    public void dropEnrollment() {
        if (dropped) {
            throw new IllegalStateException("Enrollment is already dropped");
        }
        
        this.dropped = true;
        this.dropDate = LocalDate.now();
        // Clear any existing grades when dropped
        this.grade = null;
        this.marksObtained = -1;
    }
    
    public void reactivateEnrollment() {
        if (!dropped) {
            throw new IllegalStateException("Enrollment is not dropped");
        }
        
        this.dropped = false;
        this.dropDate = null;
    }
    
    // Status checking methods
    public boolean isGraded() {
        return !dropped && grade != null && marksObtained >= 0;
    }
    
    public boolean isPassing() {
        return isGraded() && grade.isPassing();
    }
    
    public boolean isActive() {
        return !dropped;
    }
    
    public String getStatus() {
        if (dropped) {
            return "Dropped";
        } else if (isGraded()) {
            return "Completed - " + grade.getLetter();
        } else {
            return "In Progress";
        }
    }
    
    // Calculate weighted grade points for GPA calculation
    public double getWeightedGradePoints(int courseCredits) {
        if (!isGraded() || courseCredits <= 0) {
            return 0.0;
        }
        return grade.getGradePoint() * courseCredits;
    }
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Enrollment that = (Enrollment) obj;
        return Objects.equals(enrollmentId, that.enrollmentId);
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(enrollmentId);
    }
    
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Enrollment[").append(enrollmentId).append("]: ");
        sb.append("Student ").append(studentId);
        sb.append(" -> Course ").append(courseCode);
        sb.append(" (").append(getStatus()).append(")");
        
        if (isGraded()) {
            sb.append(" - ").append(marksObtained).append(" marks");
        }
        
        return sb.toString();
    }
}