package edu.ccrm.exception;

/**
 * Base exception class for Campus Course & Records Manager (CCRM)
 * Demonstrates custom exception hierarchy with proper error handling
 */
public class CCRMException extends Exception {
    private final String errorCode;
    private final String context;
    
    public CCRMException(String message) {
        super(message);
        this.errorCode = "CCRM_GENERAL_ERROR";
        this.context = "";
    }
    
    public CCRMException(String message, String errorCode) {
        super(message);
        this.errorCode = errorCode;
        this.context = "";
    }
    
    public CCRMException(String message, String errorCode, String context) {
        super(message);
        this.errorCode = errorCode;
        this.context = context;
    }
    
    public CCRMException(String message, Throwable cause) {
        super(message, cause);
        this.errorCode = "CCRM_GENERAL_ERROR";
        this.context = "";
    }
    
    public CCRMException(String message, String errorCode, Throwable cause) {
        super(message, cause);
        this.errorCode = errorCode;
        this.context = "";
    }
    
    public CCRMException(String message, String errorCode, String context, Throwable cause) {
        super(message, cause);
        this.errorCode = errorCode;
        this.context = context;
    }
    
    public String getErrorCode() {
        return errorCode;
    }
    
    public String getContext() {
        return context;
    }
    
    public String getDetailedMessage() {
        StringBuilder sb = new StringBuilder();
        sb.append("[").append(errorCode).append("] ");
        sb.append(getMessage());
        
        if (context != null && !context.isEmpty()) {
            sb.append(" (Context: ").append(context).append(")");
        }
        
        return sb.toString();
    }
    
    @Override
    public String toString() {
        return getClass().getSimpleName() + ": " + getDetailedMessage();
    }
}