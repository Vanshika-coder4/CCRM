package edu.ccrm.config;

import java.nio.file.Path;
import java.nio.file.Paths;

/**
 * Application configuration using Singleton design pattern
 * Manages global application settings and data folder paths
 */
public class AppConfig {
    private static AppConfig instance;
    private final Path dataFolderPath;
    private final Path backupFolderPath;
    private final int maxCreditsPerSemester;
    
    // Private constructor for Singleton pattern
    private AppConfig() {
        this.dataFolderPath = Paths.get("data");
        this.backupFolderPath = Paths.get("backups");
        this.maxCreditsPerSemester = 18;
        
        // Create directories if they don't exist
        try {
            java.nio.file.Files.createDirectories(dataFolderPath);
            java.nio.file.Files.createDirectories(backupFolderPath);
        } catch (Exception e) {
            System.err.println("Warning: Could not create data directories: " + e.getMessage());
        }
    }
    
    // Thread-safe Singleton instance getter
    public static synchronized AppConfig getInstance() {
        if (instance == null) {
            instance = new AppConfig();
        }
        return instance;
    }
    
    // Getters for configuration values
    public Path getDataFolderPath() {
        return dataFolderPath;
    }
    
    public Path getBackupFolderPath() {
        return backupFolderPath;
    }
    
    public int getMaxCreditsPerSemester() {
        return maxCreditsPerSemester;
    }
}