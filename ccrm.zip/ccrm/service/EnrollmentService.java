package edu.ccrm.service;

import edu.ccrm.domain.*;
import edu.ccrm.exception.*;
import java.util.*;
import java.util.stream.Collectors;
import java.time.LocalDate;

/**
 * Enrollment Service - orchestrates student-course relationships and business rules
 * Demonstrates service orchestration and business rule enforcement
 */
public class EnrollmentService {
    private final Map<String, Enrollment> enrollments;
    private final StudentService studentService;
    private final CourseService courseService;
    private int nextEnrollmentNumber;
    
    public EnrollmentService(StudentService studentService, CourseService courseService) {
        this.enrollments = new HashMap<>();
        this.studentService = studentService;
        this.courseService = courseService;
        this.nextEnrollmentNumber = 1;
    }
    
    // Core enrollment operations with enhanced exception handling
    public Enrollment enrollStudent(String studentId, String courseCode) throws EnrollmentException, StudentNotFoundException, CourseNotFoundException {
        // Validate student exists and is active
        Optional<Student> studentOpt = studentService.findById(studentId);
        if (studentOpt.isEmpty()) {
            throw new StudentNotFoundException(studentId);
        }
        if (!studentOpt.get().isActive()) {
            throw new EnrollmentException(EnrollmentException.EnrollmentError.STUDENT_INACTIVE, studentId, courseCode);
        }
        
        // Validate course exists and is active
        Optional<Course> courseOpt = courseService.findByCode(courseCode);
        if (courseOpt.isEmpty()) {
            throw new CourseNotFoundException(courseCode);
        }
        if (!courseOpt.get().isActive()) {
            throw new EnrollmentException(EnrollmentException.EnrollmentError.COURSE_INACTIVE, studentId, courseCode);
        }
        
        Course course = courseOpt.get();
        Student student = studentOpt.get();
        
        // Check if student is already enrolled
        if (isStudentEnrolled(studentId, courseCode)) {
            throw new EnrollmentException(EnrollmentException.EnrollmentError.ALREADY_ENROLLED, studentId, courseCode);
        }
        
        // Check course capacity
        if (!course.hasAvailableSlots()) {
            throw new EnrollmentException(EnrollmentException.EnrollmentError.COURSE_FULL, studentId, courseCode, 
                "Course capacity: " + course.getCurrentEnrollment() + "/" + course.getMaxEnrollment());
        }
        
        // Check student credit limit (business rule)
        if (!studentService.canEnrollInCourse(studentId, course)) {
            throw new EnrollmentException(EnrollmentException.EnrollmentError.CREDIT_LIMIT_EXCEEDED, studentId, courseCode,
                "Current credits: " + student.getTotalCredits() + ", Course credits: " + course.getCredits());
        }
        
        // Create enrollment
        String enrollmentId = "ENR" + String.format("%08d", nextEnrollmentNumber++);
        Enrollment enrollment = new Enrollment(enrollmentId, studentId, courseCode);
        
        // Update system state
        enrollments.put(enrollmentId, enrollment);
        studentService.addEnrollment(studentId, enrollment);
        course.incrementEnrollment();
        
        return enrollment;
    }
    
    public boolean unenrollStudent(String studentId, String courseCode) {
        Enrollment enrollment = findActiveEnrollment(studentId, courseCode);
        if (enrollment == null) {
            return false;
        }
        
        // Drop the enrollment
        enrollment.dropEnrollment();
        
        // Update course capacity
        Optional<Course> courseOpt = courseService.findByCode(courseCode);
        courseOpt.ifPresent(Course::decrementEnrollment);
        
        // Update student's course list
        Optional<Student> studentOpt = studentService.findById(studentId);
        studentOpt.ifPresent(student -> student.unenrollFromCourse(courseCode));
        
        return true;
    }
    
    public boolean recordGrade(String studentId, String courseCode, int marks) {
        Enrollment enrollment = findActiveEnrollment(studentId, courseCode);
        if (enrollment == null) {
            throw new IllegalArgumentException("Active enrollment not found");
        }
        
        enrollment.recordGrade(marks);
        
        // Update student GPA
        recalculateStudentGPA(studentId);
        
        return true;
    }
    
    public boolean recordGrade(String studentId, String courseCode, Grade grade) {
        Enrollment enrollment = findActiveEnrollment(studentId, courseCode);
        if (enrollment == null) {
            throw new IllegalArgumentException("Active enrollment not found");
        }
        
        enrollment.recordGrade(grade);
        
        // Update student GPA
        recalculateStudentGPA(studentId);
        
        return true;
    }
    
    // Query operations
    public Optional<Enrollment> findById(String enrollmentId) {
        return Optional.ofNullable(enrollments.get(enrollmentId));
    }
    
    public List<Enrollment> getStudentEnrollments(String studentId) {
        return enrollments.values().stream()
            .filter(e -> e.getStudentId().equals(studentId))
            .collect(Collectors.toList());
    }
    
    public List<Enrollment> getCourseEnrollments(String courseCode) {
        return enrollments.values().stream()
            .filter(e -> e.getCourseCode().equals(courseCode.trim().toUpperCase()))
            .collect(Collectors.toList());
    }
    
    public List<Enrollment> getActiveEnrollments() {
        return enrollments.values().stream()
            .filter(Enrollment::isActive)
            .collect(Collectors.toList());
    }
    
    public List<Enrollment> getCompletedEnrollments() {
        return enrollments.values().stream()
            .filter(Enrollment::isGraded)
            .collect(Collectors.toList());
    }
    
    public boolean isStudentEnrolled(String studentId, String courseCode) {
        return enrollments.values().stream()
            .anyMatch(e -> e.getStudentId().equals(studentId) && 
                          e.getCourseCode().equals(courseCode.trim().toUpperCase()) &&
                          e.isActive());
    }
    
    private Enrollment findActiveEnrollment(String studentId, String courseCode) {
        return enrollments.values().stream()
            .filter(e -> e.getStudentId().equals(studentId) && 
                        e.getCourseCode().equals(courseCode.trim().toUpperCase()) &&
                        e.isActive())
            .findFirst()
            .orElse(null);
    }
    
    // GPA Calculation using Stream API
    private void recalculateStudentGPA(String studentId) {
        List<Enrollment> gradedEnrollments = enrollments.values().stream()
            .filter(e -> e.getStudentId().equals(studentId))
            .filter(Enrollment::isGraded)
            .collect(Collectors.toList());
        
        if (gradedEnrollments.isEmpty()) {
            return;
        }
        
        // Calculate weighted GPA
        double totalWeightedPoints = 0.0;
        int totalCredits = 0;
        
        for (Enrollment enrollment : gradedEnrollments) {
            Optional<Course> courseOpt = courseService.findByCode(enrollment.getCourseCode());
            if (courseOpt.isPresent()) {
                Course course = courseOpt.get();
                int credits = course.getCredits();
                double gradePoints = enrollment.getGrade().getGradePoint();
                
                totalWeightedPoints += gradePoints * credits;
                totalCredits += credits;
            }
        }
        
        double gpa = totalCredits > 0 ? totalWeightedPoints / totalCredits : 0.0;
        
        // Update student GPA
        Optional<Student> studentOpt = studentService.findById(studentId);
        final int finalTotalCredits = totalCredits; // Make variable effectively final for lambda
        studentOpt.ifPresent(student -> {
            student.setGpa(gpa);
            student.setTotalCredits(finalTotalCredits);
        });
    }
    
    // Analytics and reporting using Stream API
    public Map<Grade, Long> getGradeDistribution() {
        return enrollments.values().stream()
            .filter(Enrollment::isGraded)
            .collect(Collectors.groupingBy(
                Enrollment::getGrade,
                Collectors.counting()
            ));
    }
    
    public Map<String, Long> getEnrollmentsByCourse() {
        return enrollments.values().stream()
            .filter(Enrollment::isActive)
            .collect(Collectors.groupingBy(
                Enrollment::getCourseCode,
                Collectors.counting()
            ));
    }
    
    public List<Enrollment> getFailingEnrollments() {
        return enrollments.values().stream()
            .filter(Enrollment::isGraded)
            .filter(e -> !e.isPassing())
            .collect(Collectors.toList());
    }
    
    public List<Enrollment> getHonorsEnrollments() {
        return enrollments.values().stream()
            .filter(Enrollment::isGraded)
            .filter(e -> e.getGrade().isHonors())
            .collect(Collectors.toList());
    }
    
    public double getOverallPassRate() {
        long gradedCount = enrollments.values().stream()
            .filter(Enrollment::isGraded)
            .count();
            
        if (gradedCount == 0) return 0.0;
        
        long passingCount = enrollments.values().stream()
            .filter(Enrollment::isGraded)
            .filter(Enrollment::isPassing)
            .count();
            
        return (double) passingCount / gradedCount * 100;
    }
    
    public Map<String, Double> getCoursePassRates() {
        return enrollments.values().stream()
            .filter(Enrollment::isGraded)
            .collect(Collectors.groupingBy(
                Enrollment::getCourseCode,
                Collectors.collectingAndThen(
                    Collectors.toList(),
                    list -> {
                        long total = list.size();
                        long passing = list.stream()
                            .filter(Enrollment::isPassing)
                            .count();
                        return total > 0 ? (double) passing / total * 100 : 0.0;
                    }
                )
            ));
    }
    
    // Statistics
    public int getTotalEnrollmentCount() {
        return enrollments.size();
    }
    
    public int getActiveEnrollmentCount() {
        return (int) enrollments.values().stream()
            .filter(Enrollment::isActive)
            .count();
    }
    
    public int getCompletedEnrollmentCount() {
        return (int) enrollments.values().stream()
            .filter(Enrollment::isGraded)
            .count();
    }
    
    public Map<String, Object> getEnrollmentStatistics() {
        Map<String, Object> stats = new HashMap<>();
        stats.put("totalEnrollments", getTotalEnrollmentCount());
        stats.put("activeEnrollments", getActiveEnrollmentCount());
        stats.put("completedEnrollments", getCompletedEnrollmentCount());
        stats.put("overallPassRate", getOverallPassRate());
        stats.put("gradeDistribution", getGradeDistribution());
        stats.put("coursePassRates", getCoursePassRates());
        return stats;
    }
}