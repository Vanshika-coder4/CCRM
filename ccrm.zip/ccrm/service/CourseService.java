package edu.ccrm.service;

import edu.ccrm.domain.*;
import java.util.*;
import java.util.stream.Collectors;
import java.util.function.Predicate;

/**
 * Course Service - demonstrates service layer pattern with Stream API usage
 * Manages course operations and provides search/filter functionality
 */
public class CourseService {
    private final Map<String, Course> courses;
    
    public CourseService() {
        this.courses = new HashMap<>();
    }
    
    // CRUD Operations
    public Course createCourse(String code, String title, int credits, String department) {
        if (code == null || code.trim().isEmpty()) {
            throw new IllegalArgumentException("Course code is required");
        }
        
        String normalizedCode = code.trim().toUpperCase();
        
        if (courses.containsKey(normalizedCode)) {
            throw new IllegalArgumentException("Course code already exists: " + normalizedCode);
        }
        
        Course course = new Course.Builder(normalizedCode, title)
            .credits(credits)
            .department(department)
            .build();
            
        courses.put(normalizedCode, course);
        return course;
    }
    
    public Course createCourse(Course.Builder builder) {
        Course course = builder.build();
        String code = course.getCode();
        
        if (courses.containsKey(code)) {
            throw new IllegalArgumentException("Course code already exists: " + code);
        }
        
        courses.put(code, course);
        return course;
    }
    
    public Optional<Course> findByCode(String code) {
        if (code == null) return Optional.empty();
        return Optional.ofNullable(courses.get(code.trim().toUpperCase()));
    }
    
    public List<Course> getAllCourses() {
        return new ArrayList<>(courses.values());
    }
    
    public List<Course> getActiveCourses() {
        return courses.values().stream()
            .filter(Course::isActive)
            .collect(Collectors.toList());
    }
    
    public boolean updateCourse(String code, String title, Integer credits, String instructorId) {
        Course course = courses.get(code.trim().toUpperCase());
        if (course == null) {
            return false;
        }
        
        if (title != null && !title.trim().isEmpty()) {
            course.setTitle(title);
        }
        if (credits != null && credits > 0) {
            course.setCredits(credits);
        }
        if (instructorId != null) {
            course.setInstructorId(instructorId);
        }
        
        return true;
    }
    
    public boolean deactivateCourse(String code) {
        Course course = courses.get(code.trim().toUpperCase());
        if (course != null) {
            course.setActive(false);
            return true;
        }
        return false;
    }
    
    public boolean reactivateCourse(String code) {
        Course course = courses.get(code.trim().toUpperCase());
        if (course != null) {
            course.setActive(true);
            return true;
        }
        return false;
    }
    
    // Search and Filter operations using Stream API and lambda expressions
    public List<Course> searchCourses(String searchTerm) {
        if (searchTerm == null || searchTerm.trim().isEmpty()) {
            return getAllCourses();
        }
        
        String lowerSearchTerm = searchTerm.trim().toLowerCase();
        return courses.values().stream()
            .filter(course -> 
                course.getCode().toLowerCase().contains(lowerSearchTerm) ||
                course.getTitle().toLowerCase().contains(lowerSearchTerm) ||
                course.getDepartment().toLowerCase().contains(lowerSearchTerm)
            )
            .collect(Collectors.toList());
    }
    
    public List<Course> filterByDepartment(String department) {
        if (department == null || department.trim().isEmpty()) {
            return getAllCourses();
        }
        
        return courses.values().stream()
            .filter(course -> course.getDepartment().equalsIgnoreCase(department.trim()))
            .collect(Collectors.toList());
    }
    
    public List<Course> filterByInstructor(String instructorId) {
        if (instructorId == null || instructorId.trim().isEmpty()) {
            return courses.values().stream()
                .filter(course -> course.getInstructorId() == null)
                .collect(Collectors.toList());
        }
        
        return courses.values().stream()
            .filter(course -> instructorId.trim().equals(course.getInstructorId()))
            .collect(Collectors.toList());
    }
    
    public List<Course> filterBySemester(Semester semester) {
        if (semester == null) {
            return getAllCourses();
        }
        
        return courses.values().stream()
            .filter(course -> semester.equals(course.getSemester()))
            .collect(Collectors.toList());
    }
    
    public List<Course> filterByCredits(int minCredits, int maxCredits) {
        return courses.values().stream()
            .filter(course -> course.getCredits() >= minCredits && course.getCredits() <= maxCredits)
            .collect(Collectors.toList());
    }
    
    // Complex filtering with multiple criteria using functional interfaces
    public List<Course> filterCourses(Predicate<Course> filter) {
        return courses.values().stream()
            .filter(filter)
            .collect(Collectors.toList());
    }
    
    // Compound filtering methods demonstrating lambda usage
    public List<Course> getAvailableCourses() {
        return courses.values().stream()
            .filter(Course::isActive)
            .filter(Course::hasAvailableSlots)
            .collect(Collectors.toList());
    }
    
    public List<Course> getFullCourses() {
        return courses.values().stream()
            .filter(Course::isActive)
            .filter(Course::isFull)
            .collect(Collectors.toList());
    }
    
    public List<Course> getCoursesByEnrollmentCapacity(int minCapacity) {
        return courses.values().stream()
            .filter(course -> course.getMaxEnrollment() >= minCapacity)
            .sorted(Comparator.comparingInt(Course::getMaxEnrollment).reversed())
            .collect(Collectors.toList());
    }
    
    // Sorting operations using method references and comparators
    public List<Course> getCoursesSortedByCode() {
        return courses.values().stream()
            .sorted(Comparator.comparing(Course::getCode))
            .collect(Collectors.toList());
    }
    
    public List<Course> getCoursesSortedByTitle() {
        return courses.values().stream()
            .sorted(Comparator.comparing(Course::getTitle))
            .collect(Collectors.toList());
    }
    
    public List<Course> getCoursesSortedByCredits() {
        return courses.values().stream()
            .sorted(Comparator.comparing(Course::getCredits).reversed())
            .collect(Collectors.toList());
    }
    
    public List<Course> getCoursesSortedByEnrollment() {
        return courses.values().stream()
            .sorted(Comparator.comparing(Course::getCurrentEnrollment).reversed())
            .collect(Collectors.toList());
    }
    
    // Grouping operations using Collectors
    public Map<String, List<Course>> getCoursesByDepartment() {
        return courses.values().stream()
            .collect(Collectors.groupingBy(Course::getDepartment));
    }
    
    public Map<Semester, List<Course>> getCoursesBySemester() {
        return courses.values().stream()
            .collect(Collectors.groupingBy(Course::getSemester));
    }
    
    public Map<Integer, Long> getCreditDistribution() {
        return courses.values().stream()
            .collect(Collectors.groupingBy(
                Course::getCredits,
                Collectors.counting()
            ));
    }
    
    // Aggregate operations
    public int getTotalCourseCount() {
        return courses.size();
    }
    
    public int getActiveCourseCount() {
        return (int) courses.values().stream()
            .filter(Course::isActive)
            .count();
    }
    
    public int getTotalEnrollmentCapacity() {
        return courses.values().stream()
            .filter(Course::isActive)
            .mapToInt(Course::getMaxEnrollment)
            .sum();
    }
    
    public int getCurrentTotalEnrollment() {
        return courses.values().stream()
            .filter(Course::isActive)
            .mapToInt(Course::getCurrentEnrollment)
            .sum();
    }
    
    public double getAverageEnrollmentPercentage() {
        return courses.values().stream()
            .filter(Course::isActive)
            .mapToDouble(Course::getEnrollmentPercentage)
            .average()
            .orElse(0.0);
    }
    
    // Statistics and reporting
    public Map<String, Object> getCourseStatistics() {
        Map<String, Object> stats = new HashMap<>();
        stats.put("totalCourses", getTotalCourseCount());
        stats.put("activeCourses", getActiveCourseCount());
        stats.put("totalCapacity", getTotalEnrollmentCapacity());
        stats.put("currentEnrollment", getCurrentTotalEnrollment());
        stats.put("averageEnrollmentPercentage", getAverageEnrollmentPercentage());
        stats.put("departmentDistribution", getCoursesByDepartment().entrySet().stream()
            .collect(Collectors.toMap(
                Map.Entry::getKey,
                entry -> entry.getValue().size()
            )));
        stats.put("creditDistribution", getCreditDistribution());
        return stats;
    }
}