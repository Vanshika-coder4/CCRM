package edu.ccrm.util;

import edu.ccrm.domain.*;
import java.util.*;
import java.util.function.*;
import java.nio.file.*;
import java.io.IOException;

/**
 * Recursive Operations - demonstrates recursive algorithms and tree structures
 * Shows advanced recursion patterns in educational data management
 */
public class RecursiveOperations {
    
    /**
     * Academic hierarchy representation for recursive operations
     */
    public static class AcademicNode {
        private final String name;
        private final String type; // "university", "college", "department", "program"
        private final Map<String, Object> attributes;
        private final List<AcademicNode> children;
        private AcademicNode parent;
        
        public AcademicNode(String name, String type) {
            this.name = name;
            this.type = type;
            this.attributes = new HashMap<>();
            this.children = new ArrayList<>();
            this.parent = null;
        }
        
        public void addChild(AcademicNode child) {
            children.add(child);
            child.parent = this;
        }
        
        public void removeChild(AcademicNode child) {
            children.remove(child);
            child.parent = null;
        }
        
        // Getters
        public String getName() { return name; }
        public String getType() { return type; }
        public List<AcademicNode> getChildren() { return new ArrayList<>(children); }
        public AcademicNode getParent() { return parent; }
        public Map<String, Object> getAttributes() { return new HashMap<>(attributes); }
        
        public void setAttribute(String key, Object value) {
            attributes.put(key, value);
        }
        
        public Object getAttribute(String key) {
            return attributes.get(key);
        }
    }
    
    /**
     * Recursive tree traversal operations
     */
    public static class TreeTraversal {
        
        /**
         * Depth-first search with visitor pattern
         */
        public static void depthFirstTraversal(AcademicNode root, Consumer<AcademicNode> visitor) {
            if (root == null) return;
            
            visitor.accept(root);
            
            for (AcademicNode child : root.getChildren()) {
                depthFirstTraversal(child, visitor);
            }
        }
        
        /**
         * Breadth-first search using queue
         */
        public static void breadthFirstTraversal(AcademicNode root, Consumer<AcademicNode> visitor) {
            if (root == null) return;
            
            Queue<AcademicNode> queue = new LinkedList<>();
            queue.offer(root);
            
            while (!queue.isEmpty()) {
                AcademicNode current = queue.poll();
                visitor.accept(current);
                
                for (AcademicNode child : current.getChildren()) {
                    queue.offer(child);
                }
            }
        }
        
        /**
         * Find node recursively using predicate
         */
        public static Optional<AcademicNode> findNode(AcademicNode root, Predicate<AcademicNode> predicate) {
            if (root == null) return Optional.empty();
            
            if (predicate.test(root)) {
                return Optional.of(root);
            }
            
            for (AcademicNode child : root.getChildren()) {
                Optional<AcademicNode> found = findNode(child, predicate);
                if (found.isPresent()) {
                    return found;
                }
            }
            
            return Optional.empty();
        }
        
        /**
         * Collect all nodes matching predicate recursively
         */
        public static List<AcademicNode> collectNodes(AcademicNode root, Predicate<AcademicNode> predicate) {
            List<AcademicNode> result = new ArrayList<>();
            collectNodesRecursive(root, predicate, result);
            return result;
        }
        
        private static void collectNodesRecursive(AcademicNode node, Predicate<AcademicNode> predicate, List<AcademicNode> result) {
            if (node == null) return;
            
            if (predicate.test(node)) {
                result.add(node);
            }
            
            for (AcademicNode child : node.getChildren()) {
                collectNodesRecursive(child, predicate, result);
            }
        }
        
        /**
         * Calculate tree height recursively
         */
        public static int calculateHeight(AcademicNode root) {
            if (root == null || root.getChildren().isEmpty()) {
                return 0;
            }
            
            int maxChildHeight = 0;
            for (AcademicNode child : root.getChildren()) {
                maxChildHeight = Math.max(maxChildHeight, calculateHeight(child));
            }
            
            return 1 + maxChildHeight;
        }
        
        /**
         * Count total nodes recursively
         */
        public static int countNodes(AcademicNode root) {
            if (root == null) return 0;
            
            int count = 1; // Count current node
            for (AcademicNode child : root.getChildren()) {
                count += countNodes(child);
            }
            
            return count;
        }
        
        /**
         * Generate tree path from root to target node
         */
        public static List<String> getPath(AcademicNode root, AcademicNode target) {
            List<String> path = new ArrayList<>();
            if (findPath(root, target, path)) {
                return path;
            }
            return Collections.emptyList();
        }
        
        private static boolean findPath(AcademicNode current, AcademicNode target, List<String> path) {
            if (current == null) return false;
            
            path.add(current.getName());
            
            if (current.equals(target)) {
                return true;
            }
            
            for (AcademicNode child : current.getChildren()) {
                if (findPath(child, target, path)) {
                    return true;
                }
            }
            
            path.remove(path.size() - 1); // Backtrack
            return false;
        }
    }
    
    /**
     * Recursive file system operations for backup and organization
     */
    public static class FileSystemOperations {
        
        /**
         * Recursively traverse directory structure
         */
        public static void traverseDirectory(Path directory, Consumer<Path> fileProcessor, Consumer<Path> dirProcessor) {
            if (!Files.exists(directory)) return;
            
            try {
                if (Files.isDirectory(directory)) {
                    dirProcessor.accept(directory);
                    
                    try (var stream = Files.list(directory)) {
                        stream.forEach(path -> traverseDirectory(path, fileProcessor, dirProcessor));
                    }
                } else {
                    fileProcessor.accept(directory);
                }
            } catch (IOException e) {
                System.err.println("Error processing: " + directory + " - " + e.getMessage());
            }
        }
        
        /**
         * Calculate directory size recursively
         */
        public static long calculateDirectorySize(Path directory) {
            if (!Files.exists(directory) || !Files.isDirectory(directory)) {
                return 0;
            }
            
            try (var stream = Files.walk(directory)) {
                return stream
                    .filter(Files::isRegularFile)
                    .mapToLong(path -> {
                        try {
                            return Files.size(path);
                        } catch (IOException e) {
                            return 0;
                        }
                    })
                    .sum();
            } catch (IOException e) {
                return 0;
            }
        }
        
        /**
         * Find files recursively matching predicate
         */
        public static List<Path> findFiles(Path root, Predicate<Path> predicate) {
            List<Path> result = new ArrayList<>();
            findFilesRecursive(root, predicate, result);
            return result;
        }
        
        private static void findFilesRecursive(Path current, Predicate<Path> predicate, List<Path> result) {
            if (!Files.exists(current)) return;
            
            try {
                if (Files.isDirectory(current)) {
                    try (var stream = Files.list(current)) {
                        stream.forEach(path -> findFilesRecursive(path, predicate, result));
                    }
                } else if (predicate.test(current)) {
                    result.add(current);
                }
            } catch (IOException e) {
                System.err.println("Error accessing: " + current + " - " + e.getMessage());
            }
        }
        
        /**
         * Create directory tree structure representation
         */
        public static String generateDirectoryTree(Path root, int maxDepth) {
            StringBuilder sb = new StringBuilder();
            generateDirectoryTreeRecursive(root, "", true, 0, maxDepth, sb);
            return sb.toString();
        }
        
        private static void generateDirectoryTreeRecursive(Path path, String prefix, boolean isLast, 
                int currentDepth, int maxDepth, StringBuilder sb) {
            if (currentDepth > maxDepth || !Files.exists(path)) return;
            
            String connector = isLast ? "└── " : "├── ";
            sb.append(prefix).append(connector).append(path.getFileName()).append("\n");
            
            if (Files.isDirectory(path)) {
                try (var stream = Files.list(path)) {
                    List<Path> children = stream.sorted().toList();
                    
                    for (int i = 0; i < children.size(); i++) {
                        boolean isLastChild = (i == children.size() - 1);
                        String newPrefix = prefix + (isLast ? "    " : "│   ");
                        generateDirectoryTreeRecursive(children.get(i), newPrefix, isLastChild, 
                            currentDepth + 1, maxDepth, sb);
                    }
                } catch (IOException e) {
                    sb.append(prefix).append("    [Error reading directory]").append("\n");
                }
            }
        }
    }
    
    /**
     * Recursive data processing for academic analytics
     */
    public static class DataProcessing {
        
        /**
         * Recursive GPA calculation with prerequisite chains
         */
        public static double calculateCumulativeGPA(Student student, List<Enrollment> enrollments, 
                Function<String, List<String>> prerequisiteMapper) {
            
            Map<String, Double> courseGPAs = new HashMap<>();
            Map<String, Integer> courseCredits = new HashMap<>();
            
            // Process courses in prerequisite order
            for (Enrollment enrollment : enrollments) {
                if (enrollment.isGraded()) {
                    calculateCourseGPARecursive(enrollment.getCourseCode(), enrollments, 
                        prerequisiteMapper, courseGPAs, courseCredits);
                }
            }
            
            // Calculate weighted average
            double totalQualityPoints = 0.0;
            int totalCredits = 0;
            
            for (Map.Entry<String, Double> entry : courseGPAs.entrySet()) {
                String courseCode = entry.getKey();
                double gpa = entry.getValue();
                int credits = courseCredits.getOrDefault(courseCode, 3); // Default 3 credits
                
                totalQualityPoints += gpa * credits;
                totalCredits += credits;
            }
            
            return totalCredits > 0 ? totalQualityPoints / totalCredits : 0.0;
        }
        
        private static double calculateCourseGPARecursive(String courseCode, List<Enrollment> enrollments,
                Function<String, List<String>> prerequisiteMapper, Map<String, Double> courseGPAs, 
                Map<String, Integer> courseCredits) {
            
            // Check if already calculated
            if (courseGPAs.containsKey(courseCode)) {
                return courseGPAs.get(courseCode);
            }
            
            // Find enrollment for this course
            Optional<Enrollment> enrollmentOpt = enrollments.stream()
                .filter(e -> e.getCourseCode().equals(courseCode) && e.isGraded())
                .findFirst();
            
            if (enrollmentOpt.isEmpty()) {
                return 0.0;
            }
            
            Enrollment enrollment = enrollmentOpt.get();
            double baseGPA = enrollment.getGrade().getGradePoint();
            
            // Calculate prerequisite bonus (recursive call)
            List<String> prerequisites = prerequisiteMapper.apply(courseCode);
            double prerequisiteBonus = 0.0;
            
            if (prerequisites != null && !prerequisites.isEmpty()) {
                double totalPrereqGPA = 0.0;
                int prereqCount = 0;
                
                for (String prereq : prerequisites) {
                    double prereqGPA = calculateCourseGPARecursive(prereq, enrollments, 
                        prerequisiteMapper, courseGPAs, courseCredits);
                    if (prereqGPA > 0) {
                        totalPrereqGPA += prereqGPA;
                        prereqCount++;
                    }
                }
                
                if (prereqCount > 0) {
                    double avgPrereqGPA = totalPrereqGPA / prereqCount;
                    // Small bonus for strong prerequisite performance
                    prerequisiteBonus = Math.min(0.1, (avgPrereqGPA - 3.0) * 0.05);
                }
            }
            
            double finalGPA = Math.min(4.0, baseGPA + prerequisiteBonus);
            courseGPAs.put(courseCode, finalGPA);
            courseCredits.put(courseCode, 3); // Default credits, could be parameterized
            
            return finalGPA;
        }
        
        /**
         * Recursive enrollment validation with dependency checking
         */
        public static boolean validateEnrollmentChain(String studentId, String courseCode, 
                Function<String, List<String>> prerequisiteMapper, Function<String, Boolean> enrollmentChecker) {
            
            return validateEnrollmentRecursive(studentId, courseCode, prerequisiteMapper, 
                enrollmentChecker, new HashSet<>());
        }
        
        private static boolean validateEnrollmentRecursive(String studentId, String courseCode,
                Function<String, List<String>> prerequisiteMapper, Function<String, Boolean> enrollmentChecker,
                Set<String> visited) {
            
            // Prevent infinite loops in prerequisite chains
            if (visited.contains(courseCode)) {
                return false; // Circular dependency detected
            }
            
            visited.add(courseCode);
            
            // Check if student has completed prerequisites
            List<String> prerequisites = prerequisiteMapper.apply(courseCode);
            if (prerequisites != null) {
                for (String prereq : prerequisites) {
                    // Recursively check prerequisite completion
                    if (!enrollmentChecker.apply(prereq) || 
                        !validateEnrollmentRecursive(studentId, prereq, prerequisiteMapper, 
                            enrollmentChecker, new HashSet<>(visited))) {
                        return false;
                    }
                }
            }
            
            return true;
        }
        
        /**
         * Recursive degree audit with requirement tree
         */
        public static Map<String, Boolean> auditDegreeRequirements(Student student, 
                AcademicNode requirementTree, Function<String, Boolean> completionChecker) {
            
            Map<String, Boolean> auditResults = new HashMap<>();
            auditRequirementsRecursive(requirementTree, completionChecker, auditResults);
            return auditResults;
        }
        
        private static boolean auditRequirementsRecursive(AcademicNode node, 
                Function<String, Boolean> completionChecker, Map<String, Boolean> results) {
            
            if (node == null) return true;
            
            boolean nodeResult = true;
            
            // If this is a leaf node (actual requirement), check completion
            if (node.getChildren().isEmpty()) {
                nodeResult = completionChecker.apply(node.getName());
                results.put(node.getName(), nodeResult);
                return nodeResult;
            }
            
            // For parent nodes, determine based on type
            String requirementType = (String) node.getAttribute("type");
            
            if ("ALL".equals(requirementType)) {
                // All children must be satisfied
                for (AcademicNode child : node.getChildren()) {
                    if (!auditRequirementsRecursive(child, completionChecker, results)) {
                        nodeResult = false;
                    }
                }
            } else if ("ANY".equals(requirementType)) {
                // At least one child must be satisfied
                nodeResult = false;
                for (AcademicNode child : node.getChildren()) {
                    if (auditRequirementsRecursive(child, completionChecker, results)) {
                        nodeResult = true;
                    }
                }
            } else if ("MINIMUM".equals(requirementType)) {
                // Minimum number of children must be satisfied
                int required = (Integer) node.getAttribute("minimum");
                int satisfied = 0;
                
                for (AcademicNode child : node.getChildren()) {
                    if (auditRequirementsRecursive(child, completionChecker, results)) {
                        satisfied++;
                    }
                }
                
                nodeResult = satisfied >= required;
            }
            
            results.put(node.getName(), nodeResult);
            return nodeResult;
        }
    }
    
    /**
     * Recursive sorting and search algorithms for educational data
     */
    public static class RecursiveAlgorithms {
        
        /**
         * Merge sort implementation for student records
         */
        public static <T> List<T> mergeSort(List<T> list, Comparator<T> comparator) {
            if (list.size() <= 1) {
                return new ArrayList<>(list);
            }
            
            int mid = list.size() / 2;
            List<T> left = mergeSort(list.subList(0, mid), comparator);
            List<T> right = mergeSort(list.subList(mid, list.size()), comparator);
            
            return merge(left, right, comparator);
        }
        
        private static <T> List<T> merge(List<T> left, List<T> right, Comparator<T> comparator) {
            List<T> result = new ArrayList<>();
            int i = 0, j = 0;
            
            while (i < left.size() && j < right.size()) {
                if (comparator.compare(left.get(i), right.get(j)) <= 0) {
                    result.add(left.get(i++));
                } else {
                    result.add(right.get(j++));
                }
            }
            
            while (i < left.size()) result.add(left.get(i++));
            while (j < right.size()) result.add(right.get(j++));
            
            return result;
        }
        
        /**
         * Binary search for sorted data
         */
        public static <T> int binarySearch(List<T> list, T target, Comparator<T> comparator) {
            return binarySearchRecursive(list, target, 0, list.size() - 1, comparator);
        }
        
        private static <T> int binarySearchRecursive(List<T> list, T target, int left, int right, 
                Comparator<T> comparator) {
            if (left > right) {
                return -1;
            }
            
            int mid = left + (right - left) / 2;
            int comparison = comparator.compare(list.get(mid), target);
            
            if (comparison == 0) {
                return mid;
            } else if (comparison < 0) {
                return binarySearchRecursive(list, target, mid + 1, right, comparator);
            } else {
                return binarySearchRecursive(list, target, left, mid - 1, comparator);
            }
        }
        
        /**
         * Quick sort with custom partitioning
         */
        public static <T> void quickSort(List<T> list, Comparator<T> comparator) {
            quickSortRecursive(list, 0, list.size() - 1, comparator);
        }
        
        private static <T> void quickSortRecursive(List<T> list, int low, int high, Comparator<T> comparator) {
            if (low < high) {
                int partitionIndex = partition(list, low, high, comparator);
                quickSortRecursive(list, low, partitionIndex - 1, comparator);
                quickSortRecursive(list, partitionIndex + 1, high, comparator);
            }
        }
        
        private static <T> int partition(List<T> list, int low, int high, Comparator<T> comparator) {
            T pivot = list.get(high);
            int i = low - 1;
            
            for (int j = low; j < high; j++) {
                if (comparator.compare(list.get(j), pivot) <= 0) {
                    i++;
                    Collections.swap(list, i, j);
                }
            }
            
            Collections.swap(list, i + 1, high);
            return i + 1;
        }
    }
}