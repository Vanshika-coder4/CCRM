package edu.ccrm.util;

import edu.ccrm.domain.*;
import java.util.*;
import java.util.function.*;
import java.util.stream.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Stream API Utilities - demonstrates advanced Stream operations, lambdas, and functional interfaces
 * Showcases modern Java functional programming capabilities
 */
public class StreamUtilities {
    
    // Custom functional interfaces demonstrating lambda expressions
    @FunctionalInterface
    public interface StudentPredicate {
        boolean test(Student student);
        
        // Default method demonstrating functional interface enhancements
        default StudentPredicate and(StudentPredicate other) {
            return student -> this.test(student) && other.test(student);
        }
        
        default StudentPredicate or(StudentPredicate other) {
            return student -> this.test(student) || other.test(student);
        }
        
        default StudentPredicate negate() {
            return student -> !this.test(student);
        }
    }
    
    @FunctionalInterface
    public interface GradeAnalyzer {
        double analyze(List<Enrollment> enrollments);
    }
    
    @FunctionalInterface
    public interface CourseTransformer<T> {
        T transform(Course course);
    }
    
    // Advanced Stream operations for student analysis
    public static class StudentAnalytics {
        
        /**
         * Find top performing students using Stream API with custom comparators
         */
        public static List<Student> getTopStudents(Collection<Student> students, int limit) {
            return students.stream()
                .filter(Student::isActive)
                .filter(student -> student.getGpa() > 0.0) // Has recorded grades
                .sorted(Comparator.comparingDouble(Student::getGpa)
                    .reversed()
                    .thenComparing(Student::getTotalCredits, Comparator.reverseOrder())
                    .thenComparing(Student::getFullName))
                .limit(limit)
                .collect(Collectors.toList());
        }
        
        /**
         * Group students by academic standing using advanced grouping collectors
         */
        public static Map<String, List<Student>> groupByAcademicStanding(Collection<Student> students) {
            return students.stream()
                .filter(Student::isActive)
                .collect(Collectors.groupingBy(
                    student -> determineAcademicStanding(student.getGpa()),
                    LinkedHashMap::new, // Preserve order
                    Collectors.toList()
                ));
        }
        
        /**
         * Calculate detailed GPA statistics using downstream collectors
         */
        public static Map<String, DoubleSummaryStatistics> getGpaStatisticsByDepartment(
                Collection<Student> students, Function<Student, String> departmentExtractor) {
            return students.stream()
                .filter(Student::isActive)
                .filter(student -> student.getGpa() > 0.0)
                .collect(Collectors.groupingBy(
                    departmentExtractor,
                    Collectors.summarizingDouble(Student::getGpa)
                ));
        }
        
        /**
         * Find students meeting complex criteria using predicate composition
         */
        public static List<Student> findStudentsMatching(Collection<Student> students, StudentPredicate predicate) {
            return students.stream()
                .filter(predicate::test)
                .sorted(Comparator.comparing(Student::getFullName))
                .collect(Collectors.toList());
        }
        
        /**
         * Create honor roll using multiple criteria and custom collectors
         */
        public static Map<String, Set<Student>> createHonorRoll(Collection<Student> students) {
            // Define predicates using lambda expressions
            StudentPredicate deansList = student -> student.getGpa() >= 3.5 && student.getTotalCredits() >= 12;
            StudentPredicate honorsList = student -> student.getGpa() >= 3.25 && student.getTotalCredits() >= 12;
            StudentPredicate goodStanding = student -> student.getGpa() >= 2.0;
            
            Map<String, Set<Student>> honorRoll = new LinkedHashMap<>();
            
            honorRoll.put("Dean's List", students.stream()
                .filter(deansList::test)
                .collect(Collectors.toCollection(LinkedHashSet::new)));
                
            honorRoll.put("Honor Roll", students.stream()
                .filter(honorsList.and(deansList.negate())::test)
                .collect(Collectors.toCollection(LinkedHashSet::new)));
                
            honorRoll.put("Good Standing", students.stream()
                .filter(goodStanding.and(honorsList.negate())::test)
                .collect(Collectors.toCollection(LinkedHashSet::new)));
                
            return honorRoll;
        }
        
        private static String determineAcademicStanding(double gpa) {
            if (gpa >= 3.5) return "Dean's List";
            if (gpa >= 3.0) return "Honor Roll";
            if (gpa >= 2.0) return "Good Standing";
            if (gpa >= 1.0) return "Academic Warning";
            return "Academic Probation";
        }
    }
    
    // Course analysis with advanced stream operations
    public static class CourseAnalytics {
        
        /**
         * Find popular courses using parallel streams for performance
         */
        public static List<Course> getMostPopularCourses(Collection<Course> courses, int limit) {
            return courses.parallelStream()
                .filter(Course::isActive)
                .sorted(Comparator.comparingInt(Course::getCurrentEnrollment)
                    .reversed()
                    .thenComparing(course -> (double) course.getCurrentEnrollment() / course.getMaxEnrollment(), Comparator.reverseOrder())
                    .thenComparing(Course::getCode))
                .limit(limit)
                .collect(Collectors.toList());
        }
        
        /**
         * Analyze course distribution using complex grouping operations
         */
        public static Map<String, Map<Semester, Long>> getCourseDistributionByDepartment(Collection<Course> courses) {
            return courses.stream()
                .filter(Course::isActive)
                .collect(Collectors.groupingBy(
                    Course::getDepartment,
                    Collectors.groupingBy(
                        Course::getSemester,
                        Collectors.counting()
                    )
                ));
        }
        
        /**
         * Find courses with availability using method references and predicates
         */
        public static List<Course> getAvailableCourses(Collection<Course> courses) {
            return courses.stream()
                .filter(Course::isActive)
                .filter(Course::hasAvailableSlots)
                .sorted(Comparator.comparing(Course::getDepartment)
                    .thenComparing(Course::getCode))
                .collect(Collectors.toList());
        }
        
        /**
         * Transform courses using custom transformer function
         */
        public static <T> List<T> transformCourses(Collection<Course> courses, CourseTransformer<T> transformer) {
            return courses.stream()
                .filter(Course::isActive)
                .map(transformer::transform)
                .collect(Collectors.toList());
        }
        
        /**
         * Calculate course load statistics using reduction operations
         */
        public static OptionalDouble getAverageCourseLoad(Collection<Course> courses) {
            return courses.stream()
                .filter(Course::isActive)
                .mapToInt(Course::getCredits)
                .average();
        }
        
        /**
         * Find course conflicts using flatMap and complex logic
         */
        public static Map<String, List<Course>> findPotentialScheduleConflicts(Collection<Course> courses) {
            return courses.stream()
                .filter(Course::isActive)
                .collect(Collectors.groupingBy(
                    course -> course.getDepartment() + "-" + course.getSemester(),
                    Collectors.filtering(
                        course -> course.getCurrentEnrollment() > course.getMaxEnrollment() * 0.8,
                        Collectors.toList()
                    )
                ))
                .entrySet().stream()
                .filter(entry -> entry.getValue().size() > 1)
                .collect(Collectors.toMap(
                    Map.Entry::getKey,
                    Map.Entry::getValue
                ));
        }
    }
    
    // Enrollment analysis with lambda expressions and method references
    public static class EnrollmentAnalytics {
        
        /**
         * Analyze grade distributions using custom collectors and analyzers
         */
        public static Map<Grade, Long> getGradeDistribution(Collection<Enrollment> enrollments) {
            return enrollments.stream()
                .filter(Enrollment::isGraded)
                .collect(Collectors.groupingBy(
                    Enrollment::getGrade,
                    LinkedHashMap::new,
                    Collectors.counting()
                ))
                .entrySet().stream()
                .sorted(Map.Entry.<Grade, Long>comparingByKey(Comparator.comparing(Grade::getGradePoint).reversed()))
                .collect(Collectors.toMap(
                    Map.Entry::getKey,
                    Map.Entry::getValue,
                    (e1, e2) -> e1,
                    LinkedHashMap::new
                ));
        }
        
        /**
         * Calculate success rates using custom analyzer functions
         */
        public static double calculateSuccessRate(Collection<Enrollment> enrollments, GradeAnalyzer analyzer) {
            List<Enrollment> gradedEnrollments = enrollments.stream()
                .filter(Enrollment::isGraded)
                .collect(Collectors.toList());
                
            return analyzer.analyze(gradedEnrollments);
        }
        
        /**
         * Find at-risk students using complex predicate chains
         */
        public static List<String> findAtRiskStudents(Collection<Enrollment> enrollments) {
            return enrollments.stream()
                .filter(Enrollment::isGraded)
                .collect(Collectors.groupingBy(
                    Enrollment::getStudentId,
                    Collectors.averagingDouble(enrollment -> enrollment.getGrade().getGradePoint())
                ))
                .entrySet().stream()
                .filter(entry -> entry.getValue() < 2.0)
                .map(Map.Entry::getKey)
                .sorted()
                .collect(Collectors.toList());
        }
        
        /**
         * Generate enrollment trends using advanced stream operations
         */
        public static Map<String, IntSummaryStatistics> getEnrollmentTrends(Collection<Enrollment> enrollments) {
            return enrollments.stream()
                .filter(enrollment -> enrollment.getEnrollmentDate() != null)
                .collect(Collectors.groupingBy(
                    enrollment -> enrollment.getEnrollmentDate().getMonth().toString(),
                    LinkedHashMap::new,
                    Collectors.summarizingInt(enrollment -> 1)
                ));
        }
    }
    
    // Utility methods demonstrating functional programming patterns
    public static class FunctionalUtilities {
        
        /**
         * Memoization decorator using ConcurrentHashMap for thread safety
         */
        public static <T, R> Function<T, R> memoize(Function<T, R> function) {
            Map<T, R> cache = new ConcurrentHashMap<>();
            return input -> cache.computeIfAbsent(input, function);
        }
        
        /**
         * Compose multiple predicates using functional composition
         */
        @SafeVarargs
        public static <T> Predicate<T> allOf(Predicate<T>... predicates) {
            return Arrays.stream(predicates)
                .reduce(Predicate::and)
                .orElse(x -> true);
        }
        
        @SafeVarargs
        public static <T> Predicate<T> anyOf(Predicate<T>... predicates) {
            return Arrays.stream(predicates)
                .reduce(Predicate::or)
                .orElse(x -> false);
        }
        
        /**
         * Create pipeline of transformations using function composition
         */
        public static <T> Function<T, T> pipeline(Function<T, T>... functions) {
            return Arrays.stream(functions)
                .reduce(Function.identity(), Function::andThen);
        }
        
        /**
         * Batch processing with parallel streams
         */
        public static <T, R> List<R> processInBatches(List<T> items, Function<T, R> processor, int batchSize) {
            return IntStream.range(0, (items.size() + batchSize - 1) / batchSize)
                .parallel()
                .mapToObj(i -> items.subList(i * batchSize, Math.min((i + 1) * batchSize, items.size())))
                .flatMap(batch -> batch.stream().map(processor))
                .collect(Collectors.toList());
        }
    }
    
    // Predefined analyzers demonstrating lambda expressions
    public static final GradeAnalyzer PASS_RATE_ANALYZER = enrollments -> {
        long total = enrollments.size();
        long passing = enrollments.stream()
            .mapToLong(enrollment -> enrollment.getGrade().getGradePoint() >= 2.0 ? 1 : 0)
            .sum();
        return total > 0 ? (double) passing / total * 100.0 : 0.0;
    };
    
    public static final GradeAnalyzer AVERAGE_GPA_ANALYZER = enrollments -> 
        enrollments.stream()
            .mapToDouble(enrollment -> enrollment.getGrade().getGradePoint())
            .average()
            .orElse(0.0);
    
    public static final GradeAnalyzer EXCELLENCE_RATE_ANALYZER = enrollments -> {
        long total = enrollments.size();
        long excellent = enrollments.stream()
            .mapToLong(enrollment -> enrollment.getGrade().getGradePoint() >= 3.5 ? 1 : 0)
            .sum();
        return total > 0 ? (double) excellent / total * 100.0 : 0.0;
    };
    
    // Predefined predicates using lambda expressions
    public static final StudentPredicate HONOR_STUDENT = student -> 
        student.getGpa() >= 3.5 && student.isActive();
        
    public static final StudentPredicate AT_RISK_STUDENT = student -> 
        student.getGpa() < 2.0 && student.isActive();
        
    public static final StudentPredicate FULL_TIME_STUDENT = student -> 
        student.getTotalCredits() >= 12 && student.isActive();
    
    // Course transformers demonstrating method references and lambdas
    public static final CourseTransformer<String> COURSE_SUMMARY = course -> 
        String.format("%s - %s (%d credits, %d/%d enrolled)", 
            course.getCode(), course.getTitle(), course.getCredits(),
            course.getCurrentEnrollment(), course.getMaxEnrollment());
            
    public static final CourseTransformer<Double> ENROLLMENT_PERCENTAGE = course -> 
        course.getMaxEnrollment() > 0 ? 
            (double) course.getCurrentEnrollment() / course.getMaxEnrollment() * 100.0 : 0.0;
}