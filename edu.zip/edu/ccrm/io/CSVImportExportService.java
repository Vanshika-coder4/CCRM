package edu.ccrm.io;

import edu.ccrm.domain.*;
import edu.ccrm.service.*;
import java.nio.file.*;
import java.io.IOException;
import java.util.*;
import java.util.stream.Stream;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

/**
 * CSV Import/Export Service using NIO.2 APIs
 * Demonstrates modern file I/O with Path and Files APIs
 */
public class CSVImportExportService {
    private final StudentService studentService;
    private final CourseService courseService;
    private final EnrollmentService enrollmentService;
    
    // CSV Headers
    private static final String STUDENT_HEADER = "id,regNo,fullName,email,gpa,totalCredits,enrollmentDate,active";
    private static final String COURSE_HEADER = "code,title,credits,instructorId,semester,department,maxEnrollment,currentEnrollment,active";
    private static final String ENROLLMENT_HEADER = "enrollmentId,studentId,courseCode,enrollmentDate,grade,marksObtained,dropped,dropDate";
    
    public CSVImportExportService(StudentService studentService, CourseService courseService, 
                                EnrollmentService enrollmentService) {
        this.studentService = studentService;
        this.courseService = courseService;
        this.enrollmentService = enrollmentService;
    }
    
    // Export operations using NIO.2
    public void exportStudents(Path filePath) throws IOException {
        List<Student> students = studentService.getAllStudents();
        
        // Ensure parent directory exists
        Files.createDirectories(filePath.getParent());
        
        List<String> lines = new ArrayList<>();
        lines.add(STUDENT_HEADER);
        
        for (Student student : students) {
            String line = String.join(",",
                csvEscape(student.getId()),
                csvEscape(student.getRegNo()),
                csvEscape(student.getFullName()),
                csvEscape(student.getEmail()),
                String.valueOf(student.getGpa()),
                String.valueOf(student.getTotalCredits()),
                student.getEnrollmentDate().toString(),
                String.valueOf(student.isActive())
            );
            lines.add(line);
        }
        
        // Write all lines using NIO.2
        Files.write(filePath, lines, StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
    }
    
    public void exportCourses(Path filePath) throws IOException {
        List<Course> courses = courseService.getAllCourses();
        
        Files.createDirectories(filePath.getParent());
        
        List<String> lines = new ArrayList<>();
        lines.add(COURSE_HEADER);
        
        for (Course course : courses) {
            String line = String.join(",",
                csvEscape(course.getCode()),
                csvEscape(course.getTitle()),
                String.valueOf(course.getCredits()),
                csvEscape(course.getInstructorId()),
                course.getSemester().name(),
                csvEscape(course.getDepartment()),
                String.valueOf(course.getMaxEnrollment()),
                String.valueOf(course.getCurrentEnrollment()),
                String.valueOf(course.isActive())
            );
            lines.add(line);
        }
        
        Files.write(filePath, lines, StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
    }
    
    public void exportEnrollments(Path filePath) throws IOException {
        List<Enrollment> enrollments = enrollmentService.getActiveEnrollments();
        
        Files.createDirectories(filePath.getParent());
        
        List<String> lines = new ArrayList<>();
        lines.add(ENROLLMENT_HEADER);
        
        for (Enrollment enrollment : enrollments) {
            String line = String.join(",",
                csvEscape(enrollment.getEnrollmentId()),
                csvEscape(enrollment.getStudentId()),
                csvEscape(enrollment.getCourseCode()),
                enrollment.getEnrollmentDate().toString(),
                enrollment.getGrade() != null ? enrollment.getGrade().name() : "",
                enrollment.getMarksObtained() >= 0 ? String.valueOf(enrollment.getMarksObtained()) : "",
                String.valueOf(enrollment.isDropped()),
                enrollment.getDropDate() != null ? enrollment.getDropDate().toString() : ""
            );
            lines.add(line);
        }
        
        Files.write(filePath, lines, StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
    }
    
    // Import operations using NIO.2 and Streams
    public int importStudents(Path filePath) throws IOException {
        if (!Files.exists(filePath)) {
            throw new IOException("File does not exist: " + filePath);
        }
        
        int importedCount = 0;
        
        try (Stream<String> lines = Files.lines(filePath)) {
            List<String> lineList = lines.skip(1) // Skip header
                .filter(line -> !line.trim().isEmpty())
                .toList();
                
            for (String line : lineList) {
                try {
                    importStudentFromCSV(line);
                    importedCount++;
                } catch (Exception e) {
                    System.err.println("Error importing student from line: " + line + " - " + e.getMessage());
                }
            }
        }
        
        return importedCount;
    }
    
    public int importCourses(Path filePath) throws IOException {
        if (!Files.exists(filePath)) {
            throw new IOException("File does not exist: " + filePath);
        }
        
        int importedCount = 0;
        
        try (Stream<String> lines = Files.lines(filePath)) {
            List<String> lineList = lines.skip(1) // Skip header
                .filter(line -> !line.trim().isEmpty())
                .toList();
                
            for (String line : lineList) {
                try {
                    importCourseFromCSV(line);
                    importedCount++;
                } catch (Exception e) {
                    System.err.println("Error importing course from line: " + line + " - " + e.getMessage());
                }
            }
        }
        
        return importedCount;
    }
    
    // Helper methods for parsing CSV lines
    private void importStudentFromCSV(String csvLine) {
        String[] parts = parseCSVLine(csvLine);
        if (parts.length < 8) {
            throw new IllegalArgumentException("Invalid CSV format for student");
        }
        
        try {
            String regNo = csvUnescape(parts[1]);
            String fullName = csvUnescape(parts[2]);
            String email = csvUnescape(parts[3]);
            double gpa = Double.parseDouble(parts[4]);
            int totalCredits = Integer.parseInt(parts[5]);
            LocalDate enrollmentDate = LocalDate.parse(parts[6]);
            boolean active = Boolean.parseBoolean(parts[7]);
            
            Student student = studentService.createStudent(regNo, fullName, email);
            student.setGpa(gpa);
            student.setTotalCredits(totalCredits);
            student.setEnrollmentDate(enrollmentDate);
            student.setActive(active);
            
        } catch (Exception e) {
            throw new IllegalArgumentException("Error parsing student data: " + e.getMessage());
        }
    }
    
    private void importCourseFromCSV(String csvLine) {
        String[] parts = parseCSVLine(csvLine);
        if (parts.length < 9) {
            throw new IllegalArgumentException("Invalid CSV format for course");
        }
        
        try {
            String code = csvUnescape(parts[0]);
            String title = csvUnescape(parts[1]);
            int credits = Integer.parseInt(parts[2]);
            String instructorId = csvUnescape(parts[3]);
            Semester semester = Semester.valueOf(parts[4]);
            String department = csvUnescape(parts[5]);
            int maxEnrollment = Integer.parseInt(parts[6]);
            boolean active = Boolean.parseBoolean(parts[8]);
            
            // Create course through service
            Course course = courseService.createCourse(new Course.Builder(code, title)
                .credits(credits)
                .instructor(instructorId.isEmpty() ? null : instructorId)
                .semester(semester)
                .department(department)
                .maxEnrollment(maxEnrollment));
                
            // Apply the active flag after creation
            course.setActive(active);
                
        } catch (Exception e) {
            throw new IllegalArgumentException("Error parsing course data: " + e.getMessage());
        }
    }
    
    // Export all data to a directory
    public void exportAllData(Path exportDirectory) throws IOException {
        Files.createDirectories(exportDirectory);
        
        String timestamp = LocalDate.now().format(DateTimeFormatter.ofPattern("yyyyMMdd"));
        
        exportStudents(exportDirectory.resolve("students_" + timestamp + ".csv"));
        exportCourses(exportDirectory.resolve("courses_" + timestamp + ".csv"));
        exportEnrollments(exportDirectory.resolve("enrollments_" + timestamp + ".csv"));
        
        // Create an export summary
        List<String> summary = Arrays.asList(
            "CCRM Data Export Summary",
            "========================",
            "Export Date: " + LocalDate.now(),
            "Students exported: " + studentService.getTotalStudentCount(),
            "Courses exported: " + courseService.getTotalCourseCount(),
            "Enrollments exported: " + enrollmentService.getActiveEnrollmentCount(),
            "",
            "Files:",
            "- students_" + timestamp + ".csv",
            "- courses_" + timestamp + ".csv", 
            "- enrollments_" + timestamp + ".csv"
        );
        
        Files.write(exportDirectory.resolve("export_summary.txt"), summary);
    }
    
    // Utility methods for CSV escaping
    private String csvEscape(String value) {
        if (value == null) return "";
        if (value.contains(",") || value.contains("\"") || value.contains("\n")) {
            return "\"" + value.replace("\"", "\"\"") + "\"";
        }
        return value;
    }
    
    private String csvUnescape(String value) {
        if (value == null) return "";
        if (value.startsWith("\"") && value.endsWith("\"")) {
            return value.substring(1, value.length() - 1).replace("\"\"", "\"");
        }
        return value;
    }
    
    // Proper CSV parsing that handles quoted values with commas
    private String[] parseCSVLine(String line) {
        List<String> fields = new ArrayList<>();
        StringBuilder currentField = new StringBuilder();
        boolean inQuotes = false;
        boolean quoteStarted = false;
        
        for (int i = 0; i < line.length(); i++) {
            char ch = line.charAt(i);
            
            if (ch == '"') {
                if (!inQuotes) {
                    inQuotes = true;
                    quoteStarted = true;
                } else {
                    // Check if this is an escaped quote
                    if (i + 1 < line.length() && line.charAt(i + 1) == '"') {
                        currentField.append('"');
                        i++; // Skip the next quote
                    } else {
                        inQuotes = false;
                    }
                }
            } else if (ch == ',' && !inQuotes) {
                fields.add(currentField.toString());
                currentField = new StringBuilder();
                quoteStarted = false;
            } else {
                currentField.append(ch);
            }
        }
        
        // Add the last field
        fields.add(currentField.toString());
        return fields.toArray(new String[0]);
    }
    
    // File validation utilities
    public boolean isValidCSVFile(Path filePath) {
        try {
            return Files.exists(filePath) && 
                   Files.isReadable(filePath) && 
                   filePath.toString().toLowerCase().endsWith(".csv");
        } catch (Exception e) {
            return false;
        }
    }
    
    public long getFileSize(Path filePath) throws IOException {
        return Files.size(filePath);
    }
    
    public String getFileInfo(Path filePath) throws IOException {
        if (!Files.exists(filePath)) {
            return "File does not exist";
        }
        
        return String.format("File: %s, Size: %d bytes, Last Modified: %s",
            filePath.getFileName(),
            Files.size(filePath),
            Files.getLastModifiedTime(filePath)
        );
    }
}