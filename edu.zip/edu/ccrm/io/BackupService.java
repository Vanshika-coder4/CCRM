package edu.ccrm.io;

import edu.ccrm.config.AppConfig;
import java.nio.file.*;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Stream;

/**
 * Backup Service using NIO.2 APIs with recursive utilities
 * Demonstrates Path, Files, walk, copy, move operations and recursion
 */
public class BackupService {
    private final CSVImportExportService importExportService;
    private final AppConfig appConfig;
    
    public BackupService(CSVImportExportService importExportService) {
        this.importExportService = importExportService;
        this.appConfig = AppConfig.getInstance();
    }
    
    // Main backup operation using NIO.2
    public Path createBackup() throws IOException {
        // Create timestamped backup directory
        String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss"));
        Path backupDir = appConfig.getBackupFolderPath().resolve("backup_" + timestamp);
        
        Files.createDirectories(backupDir);
        
        // Export all data to backup directory
        importExportService.exportAllData(backupDir);
        
        // Copy configuration files if they exist
        copyConfigurationFiles(backupDir);
        
        // Create backup manifest
        createBackupManifest(backupDir);
        
        System.out.println("Backup created successfully at: " + backupDir.toAbsolutePath());
        return backupDir;
    }
    
    // Copy files using NIO.2 operations - demonstrates Files.copy
    private void copyConfigurationFiles(Path backupDir) throws IOException {
        Path configDir = backupDir.resolve("config");
        Files.createDirectories(configDir);
        
        // Create sample config files in data directory first
        Path sourceConfigDir = appConfig.getDataFolderPath().resolve("config");
        Files.createDirectories(sourceConfigDir);
        createSampleConfigFiles(sourceConfigDir);
        
        // Demonstrate Files.copy by copying configuration files
        try (Stream<Path> files = Files.list(sourceConfigDir)) {
            for (Path sourceFile : files.filter(Files::isRegularFile).toList()) {
                Path targetFile = configDir.resolve(sourceFile.getFileName());
                Files.copy(sourceFile, targetFile, StandardCopyOption.REPLACE_EXISTING);
                System.out.println("Copied: " + sourceFile.getFileName());
            }
        }
    }
    
    private void createSampleConfigFiles(Path configDir) throws IOException {
        // Create sample configuration files for demonstration
        List<String> appSettings = Arrays.asList(
            "# CCRM Application Settings",
            "max.credits.per.semester=18",
            "default.course.credits=3",
            "backup.retention.days=30"
        );
        Files.write(configDir.resolve("application.properties"), appSettings);
        
        List<String> systemInfo = Arrays.asList(
            "# System Information",
            "java.version=" + System.getProperty("java.version"),
            "os.name=" + System.getProperty("os.name"),
            "backup.timestamp=" + LocalDateTime.now()
        );
        Files.write(configDir.resolve("system.info"), systemInfo);
    }
    
    // Create backup manifest with file listing - demonstrates Files.move
    private void createBackupManifest(Path backupDir) throws IOException {
        List<String> manifest = new ArrayList<>();
        manifest.add("CCRM Backup Manifest");
        manifest.add("===================");
        manifest.add("Created: " + LocalDateTime.now());
        manifest.add("Location: " + backupDir.toAbsolutePath());
        manifest.add("");
        manifest.add("Files in backup:");
        
        // Recursively list all files in backup
        try (Stream<Path> paths = Files.walk(backupDir)) {
            paths.filter(Files::isRegularFile)
                 .sorted()
                 .forEach(path -> {
                     try {
                         String relativePath = backupDir.relativize(path).toString();
                         long size = Files.size(path);
                         manifest.add(String.format("  %s (%d bytes)", relativePath, size));
                     } catch (IOException e) {
                         manifest.add("  " + path.getFileName() + " (size unknown)");
                     }
                 });
        }
        
        manifest.add("");
        manifest.add("Total backup size: " + calculateDirectorySize(backupDir) + " bytes");
        
        // Demonstrate Files.move - write to temporary file then move atomically
        Path tempManifest = backupDir.resolve("MANIFEST.tmp");
        Files.write(tempManifest, manifest);
        
        Path finalManifest = backupDir.resolve("MANIFEST.txt");
        Files.move(tempManifest, finalManifest, StandardCopyOption.REPLACE_EXISTING);
        System.out.println("Manifest created via atomic move operation");
    }
    
    // Recursive utility to calculate directory size
    public long calculateDirectorySize(Path directory) {
        if (!Files.exists(directory) || !Files.isDirectory(directory)) {
            return 0;
        }
        
        return calculateDirectorySizeRecursive(directory);
    }
    
    // Recursive method demonstrating recursion requirement
    private long calculateDirectorySizeRecursive(Path directory) {
        long totalSize = 0;
        
        try (Stream<Path> paths = Files.list(directory)) {
            for (Path path : paths.toList()) {
                if (Files.isDirectory(path)) {
                    // Recursive call for subdirectories
                    totalSize += calculateDirectorySizeRecursive(path);
                } else if (Files.isRegularFile(path)) {
                    try {
                        totalSize += Files.size(path);
                    } catch (IOException e) {
                        System.err.println("Error reading file size: " + path);
                    }
                }
            }
        } catch (IOException e) {
            System.err.println("Error listing directory: " + directory);
        }
        
        return totalSize;
    }
    
    // Recursive file listing with depth information
    public void printDirectoryStructure(Path directory) {
        printDirectoryStructure(directory, 0);
    }
    
    private void printDirectoryStructure(Path directory, int depth) {
        String indent = "  ".repeat(depth);
        System.out.println(indent + directory.getFileName() + "/");
        
        try (Stream<Path> paths = Files.list(directory)) {
            List<Path> sortedPaths = paths.sorted().toList();
            
            for (Path path : sortedPaths) {
                if (Files.isDirectory(path)) {
                    printDirectoryStructure(path, depth + 1);
                } else {
                    try {
                        long size = Files.size(path);
                        System.out.println(indent + "  " + path.getFileName() + " (" + size + " bytes)");
                    } catch (IOException e) {
                        System.out.println(indent + "  " + path.getFileName() + " (size unknown)");
                    }
                }
            }
        } catch (IOException e) {
            System.out.println(indent + "  [Error reading directory]");
        }
    }
    
    // Backup management operations
    public List<Path> listBackups() throws IOException {
        Path backupRoot = appConfig.getBackupFolderPath();
        
        if (!Files.exists(backupRoot)) {
            return new ArrayList<>();
        }
        
        try (Stream<Path> paths = Files.list(backupRoot)) {
            return paths.filter(Files::isDirectory)
                       .filter(path -> path.getFileName().toString().startsWith("backup_"))
                       .sorted(Comparator.reverseOrder()) // Most recent first
                       .toList();
        }
    }
    
    public void cleanupOldBackups(int retainCount) throws IOException {
        List<Path> backups = listBackups();
        
        if (backups.size() <= retainCount) {
            System.out.println("No old backups to clean up.");
            return;
        }
        
        List<Path> backupsToDelete = backups.subList(retainCount, backups.size());
        
        for (Path backup : backupsToDelete) {
            deleteDirectoryRecursively(backup);
            System.out.println("Deleted old backup: " + backup.getFileName());
        }
    }
    
    // Recursive directory deletion
    private void deleteDirectoryRecursively(Path directory) throws IOException {
        if (!Files.exists(directory)) {
            return;
        }
        
        try (Stream<Path> paths = Files.walk(directory)) {
            paths.sorted(Comparator.reverseOrder()) // Delete files before directories
                 .forEach(path -> {
                     try {
                         Files.delete(path);
                     } catch (IOException e) {
                         System.err.println("Error deleting: " + path + " - " + e.getMessage());
                     }
                 });
        }
    }
    
    // Restore operations
    public boolean restoreFromBackup(Path backupPath) throws IOException {
        if (!Files.exists(backupPath) || !Files.isDirectory(backupPath)) {
            throw new IllegalArgumentException("Invalid backup path: " + backupPath);
        }
        
        // Verify backup integrity
        if (!isValidBackup(backupPath)) {
            throw new IllegalArgumentException("Invalid or corrupted backup");
        }
        
        // Find CSV files in backup
        try (Stream<Path> paths = Files.walk(backupPath)) {
            List<Path> csvFiles = paths.filter(path -> path.toString().toLowerCase().endsWith(".csv"))
                                      .toList();
            
            int restoredFiles = 0;
            for (Path csvFile : csvFiles) {
                String fileName = csvFile.getFileName().toString().toLowerCase();
                
                try {
                    if (fileName.startsWith("students_")) {
                        importExportService.importStudents(csvFile);
                        restoredFiles++;
                    } else if (fileName.startsWith("courses_")) {
                        importExportService.importCourses(csvFile);
                        restoredFiles++;
                    }
                } catch (IOException e) {
                    System.err.println("Error restoring from " + fileName + ": " + e.getMessage());
                }
            }
            
            System.out.println("Restored " + restoredFiles + " data files from backup.");
            return restoredFiles > 0;
        }
    }
    
    private boolean isValidBackup(Path backupPath) {
        // Check for manifest file and basic structure
        return Files.exists(backupPath.resolve("MANIFEST.txt")) ||
               Files.exists(backupPath.resolve("export_summary.txt"));
    }
    
    // Backup statistics and reporting
    public Map<String, Object> getBackupStatistics() throws IOException {
        Map<String, Object> stats = new HashMap<>();
        List<Path> backups = listBackups();
        
        stats.put("totalBackups", backups.size());
        stats.put("backupLocation", appConfig.getBackupFolderPath().toAbsolutePath().toString());
        
        if (!backups.isEmpty()) {
            Path latestBackup = backups.get(0);
            stats.put("latestBackup", latestBackup.getFileName().toString());
            stats.put("latestBackupSize", calculateDirectorySize(latestBackup));
            
            long totalSize = backups.stream()
                                   .mapToLong(this::calculateDirectorySize)
                                   .sum();
            stats.put("totalBackupSize", totalSize);
        } else {
            stats.put("latestBackup", "None");
            stats.put("latestBackupSize", 0L);
            stats.put("totalBackupSize", 0L);
        }
        
        return stats;
    }
}