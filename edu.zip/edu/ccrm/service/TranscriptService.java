package edu.ccrm.service;

import edu.ccrm.domain.*;
import java.util.*;
import java.util.stream.Collectors;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

/**
 * Transcript Service - generates academic transcripts and reports
 * Demonstrates complex business logic and reporting functionality
 */
public class TranscriptService {
    private final StudentService studentService;
    private final CourseService courseService;
    private final EnrollmentService enrollmentService;
    
    public TranscriptService(StudentService studentService, CourseService courseService, 
                           EnrollmentService enrollmentService) {
        this.studentService = studentService;
        this.courseService = courseService;
        this.enrollmentService = enrollmentService;
    }
    
    // Transcript generation
    public String generateTranscript(String studentId) {
        Optional<Student> studentOpt = studentService.findById(studentId);
        if (studentOpt.isEmpty()) {
            throw new IllegalArgumentException("Student not found: " + studentId);
        }
        
        Student student = studentOpt.get();
        List<Enrollment> enrollments = enrollmentService.getStudentEnrollments(studentId);
        
        return buildTranscriptContent(student, enrollments);
    }
    
    private String buildTranscriptContent(Student student, List<Enrollment> enrollments) {
        StringBuilder transcript = new StringBuilder();
        
        // Header
        transcript.append("=".repeat(80)).append("\n");
        transcript.append("CAMPUS COURSE & RECORDS MANAGER (CCRM)\n");
        transcript.append("OFFICIAL ACADEMIC TRANSCRIPT\n");
        transcript.append("=".repeat(80)).append("\n\n");
        
        // Student Information
        transcript.append("STUDENT INFORMATION\n");
        transcript.append("-".repeat(40)).append("\n");
        transcript.append(String.format("Name: %s\n", student.getFullName()));
        transcript.append(String.format("Student ID: %s\n", student.getId()));
        transcript.append(String.format("Registration No: %s\n", student.getRegNo()));
        transcript.append(String.format("Email: %s\n", student.getEmail() != null ? student.getEmail() : "N/A"));
        transcript.append(String.format("Enrollment Date: %s\n", student.getEnrollmentDate()));
        transcript.append(String.format("Status: %s\n", student.isActive() ? "Active" : "Inactive"));
        transcript.append("\n");
        
        // Academic Summary
        transcript.append("ACADEMIC SUMMARY\n");
        transcript.append("-".repeat(40)).append("\n");
        transcript.append(String.format("Cumulative GPA: %.2f\n", student.getGpa()));
        transcript.append(String.format("Total Credits: %d\n", student.getTotalCredits()));
        transcript.append(String.format("Academic Standing: %s\n", student.getAcademicStanding()));
        transcript.append("\n");
        
        // Course History grouped by semester
        Map<Semester, List<Enrollment>> enrollmentsBySemester = groupEnrollmentsBySemester(enrollments);
        
        transcript.append("COURSE HISTORY\n");
        transcript.append("-".repeat(80)).append("\n");
        transcript.append(String.format("%-12s %-40s %-8s %-6s %-8s %-6s\n", 
            "Course Code", "Course Title", "Credits", "Grade", "Points", "Status"));
        transcript.append("-".repeat(80)).append("\n");
        
        double totalGradePoints = 0.0;
        int totalCredits = 0;
        
        // Sort semesters chronologically
        List<Semester> sortedSemesters = enrollmentsBySemester.keySet().stream()
            .sorted(Comparator.comparing(Semester::getOrder))
            .collect(Collectors.toList());
        
        for (Semester semester : sortedSemesters) {
            List<Enrollment> semesterEnrollments = enrollmentsBySemester.get(semester);
            
            transcript.append("\n").append(semester.getDisplayName().toUpperCase()).append("\n");
            transcript.append("-".repeat(40)).append("\n");
            
            double semesterGradePoints = 0.0;
            int semesterCredits = 0;
            
            // Sort courses by code
            semesterEnrollments.sort(Comparator.comparing(Enrollment::getCourseCode));
            
            for (Enrollment enrollment : semesterEnrollments) {
                Optional<Course> courseOpt = courseService.findByCode(enrollment.getCourseCode());
                if (courseOpt.isEmpty()) continue;
                
                Course course = courseOpt.get();
                int credits = course.getCredits();
                
                String grade = enrollment.isGraded() ? enrollment.getGrade().getLetter() : "IP";
                String points = enrollment.isGraded() ? 
                    String.format("%.1f", enrollment.getGrade().getGradePoint()) : "-";
                String status = enrollment.getStatus();
                
                transcript.append(String.format("%-12s %-40s %-8d %-6s %-8s %-6s\n",
                    course.getCode(),
                    truncate(course.getTitle(), 40),
                    credits,
                    grade,
                    points,
                    status.substring(0, Math.min(status.length(), 6))
                ));
                
                if (enrollment.isGraded() && enrollment.isPassing()) {
                    double gradePoints = enrollment.getGrade().getGradePoint() * credits;
                    semesterGradePoints += gradePoints;
                    semesterCredits += credits;
                    totalGradePoints += gradePoints;
                    totalCredits += credits;
                }
            }
            
            // Semester summary
            double semesterGPA = semesterCredits > 0 ? semesterGradePoints / semesterCredits : 0.0;
            transcript.append("-".repeat(40)).append("\n");
            transcript.append(String.format("Semester Credits: %d, GPA: %.2f\n", 
                semesterCredits, semesterGPA));
        }
        
        // Overall summary
        transcript.append("\n").append("=".repeat(80)).append("\n");
        transcript.append("TRANSCRIPT SUMMARY\n");
        transcript.append("-".repeat(40)).append("\n");
        transcript.append(String.format("Total Credits Attempted: %d\n", 
            enrollments.stream().mapToInt(e -> {
                Optional<Course> c = courseService.findByCode(e.getCourseCode());
                return c.map(Course::getCredits).orElse(0);
            }).sum()));
        transcript.append(String.format("Total Credits Earned: %d\n", totalCredits));
        transcript.append(String.format("Cumulative GPA: %.2f\n", 
            totalCredits > 0 ? totalGradePoints / totalCredits : 0.0));
        
        // Footer
        transcript.append("\n").append("-".repeat(80)).append("\n");
        transcript.append(String.format("Generated on: %s\n", 
            LocalDate.now().format(DateTimeFormatter.ofPattern("MMMM dd, yyyy"))));
        transcript.append("This is an official transcript generated by CCRM.\n");
        transcript.append("=".repeat(80)).append("\n");
        
        return transcript.toString();
    }
    
    private Map<Semester, List<Enrollment>> groupEnrollmentsBySemester(List<Enrollment> enrollments) {
        Map<Semester, List<Enrollment>> grouped = new HashMap<>();
        
        for (Enrollment enrollment : enrollments) {
            Optional<Course> courseOpt = courseService.findByCode(enrollment.getCourseCode());
            if (courseOpt.isPresent()) {
                Semester semester = courseOpt.get().getSemester();
                grouped.computeIfAbsent(semester, k -> new ArrayList<>()).add(enrollment);
            }
        }
        
        return grouped;
    }
    
    // Grade report generation
    public String generateGradeReport(String studentId, Semester semester) {
        Optional<Student> studentOpt = studentService.findById(studentId);
        if (studentOpt.isEmpty()) {
            throw new IllegalArgumentException("Student not found: " + studentId);
        }
        
        Student student = studentOpt.get();
        List<Enrollment> semesterEnrollments = enrollmentService.getStudentEnrollments(studentId)
            .stream()
            .filter(e -> {
                Optional<Course> courseOpt = courseService.findByCode(e.getCourseCode());
                return courseOpt.map(c -> c.getSemester() == semester).orElse(false);
            })
            .collect(Collectors.toList());
        
        return buildGradeReportContent(student, semesterEnrollments, semester);
    }
    
    private String buildGradeReportContent(Student student, List<Enrollment> enrollments, 
                                         Semester semester) {
        StringBuilder report = new StringBuilder();
        
        // Header
        report.append("=".repeat(60)).append("\n");
        report.append("SEMESTER GRADE REPORT\n");
        report.append("=".repeat(60)).append("\n\n");
        
        report.append(String.format("Student: %s (%s)\n", student.getFullName(), student.getRegNo()));
        report.append(String.format("Semester: %s\n", semester.getDisplayName()));
        report.append(String.format("Report Date: %s\n\n", 
            LocalDate.now().format(DateTimeFormatter.ofPattern("MMMM dd, yyyy"))));
        
        // Course grades
        report.append(String.format("%-12s %-30s %-8s %-6s %-8s\n", 
            "Course", "Title", "Credits", "Grade", "Points"));
        report.append("-".repeat(60)).append("\n");
        
        double totalGradePoints = 0.0;
        int totalCredits = 0;
        
        for (Enrollment enrollment : enrollments) {
            Optional<Course> courseOpt = courseService.findByCode(enrollment.getCourseCode());
            if (courseOpt.isEmpty()) continue;
            
            Course course = courseOpt.get();
            int credits = course.getCredits();
            
            String grade = enrollment.isGraded() ? enrollment.getGrade().getLetter() : "IP";
            String points = enrollment.isGraded() ? 
                String.format("%.1f", enrollment.getGrade().getGradePoint()) : "-";
            
            report.append(String.format("%-12s %-30s %-8d %-6s %-8s\n",
                course.getCode(),
                truncate(course.getTitle(), 30),
                credits,
                grade,
                points
            ));
            
            if (enrollment.isGraded() && enrollment.isPassing()) {
                totalGradePoints += enrollment.getGrade().getGradePoint() * credits;
                totalCredits += credits;
            }
        }
        
        // Summary
        report.append("-".repeat(60)).append("\n");
        double semesterGPA = totalCredits > 0 ? totalGradePoints / totalCredits : 0.0;
        report.append(String.format("Semester Credits: %d\n", totalCredits));
        report.append(String.format("Semester GPA: %.2f\n", semesterGPA));
        report.append(String.format("Cumulative GPA: %.2f\n", student.getGpa()));
        
        return report.toString();
    }
    
    // Utility methods
    private String truncate(String text, int maxLength) {
        if (text == null) return "";
        return text.length() <= maxLength ? text : text.substring(0, maxLength - 3) + "...";
    }
    
    // Transcript analysis
    public Map<String, Object> analyzeTranscript(String studentId) {
        Optional<Student> studentOpt = studentService.findById(studentId);
        if (studentOpt.isEmpty()) {
            throw new IllegalArgumentException("Student not found: " + studentId);
        }
        
        Student student = studentOpt.get();
        List<Enrollment> enrollments = enrollmentService.getStudentEnrollments(studentId);
        
        Map<String, Object> analysis = new HashMap<>();
        
        // Basic metrics
        analysis.put("totalCourses", enrollments.size());
        analysis.put("completedCourses", enrollments.stream()
            .filter(Enrollment::isGraded)
            .count());
        analysis.put("inProgressCourses", enrollments.stream()
            .filter(e -> e.isActive() && !e.isGraded())
            .count());
        analysis.put("droppedCourses", enrollments.stream()
            .filter(Enrollment::isDropped)
            .count());
        
        // Grade distribution
        Map<Grade, Long> gradeDistribution = enrollments.stream()
            .filter(Enrollment::isGraded)
            .collect(Collectors.groupingBy(
                Enrollment::getGrade,
                Collectors.counting()
            ));
        analysis.put("gradeDistribution", gradeDistribution);
        
        // Academic performance
        analysis.put("gpa", student.getGpa());
        analysis.put("totalCredits", student.getTotalCredits());
        analysis.put("academicStanding", student.getAcademicStanding());
        analysis.put("isOnProbation", student.isOnProbation());
        
        return analysis;
    }
}