package edu.ccrm.cli;

import edu.ccrm.domain.*;
import java.util.List;
import java.util.Scanner;

/**
 * Menu Helper class - utility methods for CLI interactions
 * Demonstrates input validation and user interface patterns
 */
public class MenuHelper {
    private final Scanner scanner;
    
    public MenuHelper(Scanner scanner) {
        this.scanner = scanner;
    }
    
    // Input validation methods
    public int getMenuChoice(int maxOption) {
        while (true) {
            try {
                System.out.print("Enter your choice (0-" + maxOption + "): ");
                String input = scanner.nextLine().trim();
                
                if (input.isEmpty()) {
                    System.out.println("Please enter a number.");
                    continue;
                }
                
                int choice = Integer.parseInt(input);
                if (choice >= 0 && choice <= maxOption) {
                    return choice;
                }
                
                System.out.println("Invalid choice. Please enter a number between 0 and " + maxOption + ".");
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a number.");
            }
        }
    }
    
    public String getStringInput(String prompt, boolean required) {
        while (true) {
            System.out.print(prompt + ": ");
            String input = scanner.nextLine().trim();
            
            if (!required || !input.isEmpty()) {
                return input.isEmpty() ? null : input;
            }
            
            System.out.println("This field is required. Please enter a value.");
        }
    }
    
    public int getIntInput(String prompt, int min, int max) {
        while (true) {
            try {
                System.out.print(prompt + " (" + min + "-" + max + "): ");
                String input = scanner.nextLine().trim();
                
                if (input.isEmpty()) {
                    System.out.println("Please enter a number.");
                    continue;
                }
                
                int value = Integer.parseInt(input);
                if (value >= min && value <= max) {
                    return value;
                }
                
                System.out.println("Please enter a number between " + min + " and " + max + ".");
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a number.");
            }
        }
    }
    
    public double getDoubleInput(String prompt, double min, double max) {
        while (true) {
            try {
                System.out.print(prompt + " (" + min + "-" + max + "): ");
                String input = scanner.nextLine().trim();
                
                if (input.isEmpty()) {
                    System.out.println("Please enter a number.");
                    continue;
                }
                
                double value = Double.parseDouble(input);
                if (value >= min && value <= max) {
                    return value;
                }
                
                System.out.println("Please enter a number between " + min + " and " + max + ".");
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a number.");
            }
        }
    }
    
    public boolean getYesNoInput(String prompt) {
        while (true) {
            System.out.print(prompt + " (y/n): ");
            String input = scanner.nextLine().trim().toLowerCase();
            
            if (input.equals("y") || input.equals("yes")) {
                return true;
            } else if (input.equals("n") || input.equals("no")) {
                return false;
            }
            
            System.out.println("Please enter 'y' for yes or 'n' for no.");
        }
    }
    
    public Semester getSemesterInput(String prompt) {
        while (true) {
            System.out.println(prompt);
            Semester[] semesters = Semester.values();
            
            for (int i = 0; i < semesters.length; i++) {
                System.out.println((i + 1) + ". " + semesters[i].getDisplayName());
            }
            
            try {
                System.out.print("Enter semester choice (1-" + semesters.length + "): ");
                String input = scanner.nextLine().trim();
                
                if (input.isEmpty()) {
                    System.out.println("Please select a semester.");
                    continue;
                }
                
                int choice = Integer.parseInt(input);
                if (choice >= 1 && choice <= semesters.length) {
                    return semesters[choice - 1];
                }
                
                System.out.println("Invalid choice. Please select from the list.");
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a number.");
            }
        }
    }
    
    public Grade getGradeInput(String prompt) {
        while (true) {
            System.out.println(prompt);
            Grade[] grades = Grade.values();
            
            for (int i = 0; i < grades.length; i++) {
                System.out.println((i + 1) + ". " + grades[i].getLetter() + " - " + grades[i].getDescription());
            }
            
            try {
                System.out.print("Enter grade choice (1-" + grades.length + "): ");
                String input = scanner.nextLine().trim();
                
                if (input.isEmpty()) {
                    System.out.println("Please select a grade.");
                    continue;
                }
                
                int choice = Integer.parseInt(input);
                if (choice >= 1 && choice <= grades.length) {
                    return grades[choice - 1];
                }
                
                System.out.println("Invalid choice. Please select from the list.");
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a number.");
            }
        }
    }
    
    // Display methods
    public void displayHeader(String title) {
        String separator = "=".repeat(Math.max(50, title.length() + 10));
        System.out.println("\n" + separator);
        System.out.println("   " + title.toUpperCase());
        System.out.println(separator);
    }
    
    public void displaySubHeader(String title) {
        System.out.println("\n--- " + title + " ---");
    }
    
    public void displayStudentList(List<Student> students) {
        if (students.isEmpty()) {
            System.out.println("No students found.");
            return;
        }
        
        System.out.println();
        System.out.printf("%-12s %-15s %-30s %-25s %-8s %-8s%n",
            "ID", "Reg No", "Full Name", "Email", "GPA", "Credits");
        System.out.println("-".repeat(95));
        
        for (Student student : students) {
            System.out.printf("%-12s %-15s %-30s %-25s %-8.2f %-8d%n",
                student.getId(),
                student.getRegNo(),
                truncate(student.getFullName(), 30),
                truncate(student.getEmail() != null ? student.getEmail() : "N/A", 25),
                student.getGpa(),
                student.getTotalCredits()
            );
        }
        System.out.println();
    }
    
    public void displayCourseList(List<Course> courses) {
        if (courses.isEmpty()) {
            System.out.println("No courses found.");
            return;
        }
        
        System.out.println();
        System.out.printf("%-10s %-35s %-8s %-12s %-15s %-8s%n",
            "Code", "Title", "Credits", "Instructor", "Department", "Enrolled");
        System.out.println("-".repeat(90));
        
        for (Course course : courses) {
            System.out.printf("%-10s %-35s %-8d %-12s %-15s %-8s%n",
                course.getCode(),
                truncate(course.getTitle(), 35),
                course.getCredits(),
                truncate(course.getInstructorId() != null ? course.getInstructorId() : "TBA", 12),
                truncate(course.getDepartment(), 15),
                course.getCurrentEnrollment() + "/" + course.getMaxEnrollment()
            );
        }
        System.out.println();
    }
    
    public void pauseForUser() {
        System.out.print("\nPress Enter to continue...");
        scanner.nextLine();
    }
    
    private String truncate(String text, int maxLength) {
        if (text == null || text.length() <= maxLength) {
            return text != null ? text : "";
        }
        return text.substring(0, maxLength - 3) + "...";
    }
    
    public void displayError(String message) {
        System.out.println("\n❌ Error: " + message);
    }
    
    public void displaySuccess(String message) {
        System.out.println("\n✅ " + message);
    }
    
    public void displayWarning(String message) {
        System.out.println("\n⚠️  Warning: " + message);
    }
    
    public void displayInfo(String message) {
        System.out.println("\nℹ️  " + message);
    }
}