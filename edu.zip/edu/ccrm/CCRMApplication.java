package edu.ccrm;

import edu.ccrm.cli.CLIManager;
import edu.ccrm.config.AppConfig;

/**
 * Campus Course & Records Manager (CCRM)
 * Main application entry point demonstrating comprehensive Java SE features
 * 
 * This application demonstrates:
 * - OOP principles (Encapsulation, Inheritance, Abstraction, Polymorphism)
 * - Design patterns (Singleton, Builder)
 * - Modern Java features (Streams, Date/Time API, NIO.2)
 * - Exception handling and robust error management
 */
public class CCRMApplication {
    
    public static void main(String[] args) {
        System.out.println("=== Campus Course & Records Manager (CCRM) ===");
        System.out.println("A comprehensive Java SE application demonstrating advanced OOP concepts");
        System.out.println();
        
        try {
            // Initialize application configuration using Singleton pattern
            AppConfig config = AppConfig.getInstance();
            System.out.println("Application initialized successfully.");
            
            // Start CLI interface
            CLIManager cliManager = new CLIManager();
            cliManager.start();
            
        } catch (Exception e) {
            System.err.println("Application startup failed: " + e.getMessage());
            e.printStackTrace();
        }
    }
}