package edu.ccrm.domain;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Student class extending Person - demonstrates inheritance and encapsulation
 * Contains student-specific fields and methods
 */
public class Student extends Person {
    private final String regNo;
    private List<String> enrolledCourses;
    private LocalDate enrollmentDate;
    private double gpa;
    private int totalCredits;
    
    // Constructor calling super constructor
    public Student(String id, String regNo, String fullName, String email) {
        super(id, fullName, email);
        
        if (regNo == null || regNo.trim().isEmpty()) {
            throw new IllegalArgumentException("Registration number cannot be null or empty");
        }
        
        this.regNo = regNo.trim();
        this.enrolledCourses = new ArrayList<>();
        this.enrollmentDate = LocalDate.now();
        this.gpa = 0.0;
        this.totalCredits = 0;
    }
    
    // Student-specific getters and setters
    public String getRegNo() {
        return regNo;
    }
    
    public List<String> getEnrolledCourses() {
        return Collections.unmodifiableList(enrolledCourses);
    }
    
    public LocalDate getEnrollmentDate() {
        return enrollmentDate;
    }
    
    public void setEnrollmentDate(LocalDate enrollmentDate) {
        this.enrollmentDate = enrollmentDate;
    }
    
    public double getGpa() {
        return gpa;
    }
    
    public void setGpa(double gpa) {
        if (gpa < 0.0 || gpa > 10.0) {
            throw new IllegalArgumentException("GPA must be between 0.0 and 10.0");
        }
        this.gpa = gpa;
    }
    
    public int getTotalCredits() {
        return totalCredits;
    }
    
    public void setTotalCredits(int totalCredits) {
        if (totalCredits < 0) {
            throw new IllegalArgumentException("Total credits cannot be negative");
        }
        this.totalCredits = totalCredits;
    }
    
    // Business logic methods
    public void enrollInCourse(String courseCode) {
        if (courseCode == null || courseCode.trim().isEmpty()) {
            throw new IllegalArgumentException("Course code cannot be null or empty");
        }
        
        String normalizedCode = courseCode.trim().toUpperCase();
        if (!enrolledCourses.contains(normalizedCode)) {
            enrolledCourses.add(normalizedCode);
        }
    }
    
    public void unenrollFromCourse(String courseCode) {
        if (courseCode != null) {
            enrolledCourses.remove(courseCode.trim().toUpperCase());
        }
    }
    
    public boolean isEnrolledInCourse(String courseCode) {
        return courseCode != null && enrolledCourses.contains(courseCode.trim().toUpperCase());
    }
    
    // Implementation of abstract methods from Person
    @Override
    public String getPersonType() {
        return "Student";
    }
    
    @Override
    public String getDisplayInfo() {
        StringBuilder info = new StringBuilder();
        info.append("Registration No: ").append(regNo).append("\n");
        info.append("Enrollment Date: ").append(enrollmentDate).append("\n");
        info.append("GPA: ").append(String.format("%.2f", gpa)).append("\n");
        info.append("Total Credits: ").append(totalCredits).append("\n");
        info.append("Enrolled Courses (").append(enrolledCourses.size()).append("): ");
        
        if (enrolledCourses.isEmpty()) {
            info.append("None");
        } else {
            info.append(String.join(", ", enrolledCourses));
        }
        
        return info.toString();
    }
    
    // Academic standing methods
    public String getAcademicStanding() {
        if (gpa >= 9.0) return "Outstanding";
        if (gpa >= 8.0) return "Excellent";
        if (gpa >= 7.0) return "Very Good";
        if (gpa >= 6.0) return "Good";
        if (gpa >= 5.0) return "Satisfactory";
        return "Poor";
    }
    
    public boolean isOnProbation() {
        return gpa < 5.0 && totalCredits > 0;
    }
}