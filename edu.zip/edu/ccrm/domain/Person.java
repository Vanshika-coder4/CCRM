package edu.ccrm.domain;

import java.time.LocalDate;
import java.util.Objects;

/**
 * Abstract base class demonstrating abstraction and inheritance
 * Common fields and methods for Student and Instructor
 */
public abstract class Person {
    protected final String id;
    protected String fullName;
    protected String email;
    protected LocalDate dateCreated;
    protected boolean active;
    
    // Protected constructor for inheritance
    protected Person(String id, String fullName, String email) {
        if (id == null || id.trim().isEmpty()) {
            throw new IllegalArgumentException("Person ID cannot be null or empty");
        }
        if (fullName == null || fullName.trim().isEmpty()) {
            throw new IllegalArgumentException("Full name cannot be null or empty");
        }
        
        this.id = id;
        this.fullName = fullName.trim();
        this.email = email != null ? email.trim() : null;
        this.dateCreated = LocalDate.now();
        this.active = true;
    }
    
    // Encapsulation: Getters and setters
    public String getId() {
        return id;
    }
    
    public String getFullName() {
        return fullName;
    }
    
    public void setFullName(String fullName) {
        if (fullName == null || fullName.trim().isEmpty()) {
            throw new IllegalArgumentException("Full name cannot be null or empty");
        }
        this.fullName = fullName.trim();
    }
    
    public String getEmail() {
        return email;
    }
    
    public void setEmail(String email) {
        this.email = email != null ? email.trim() : null;
    }
    
    public LocalDate getDateCreated() {
        return dateCreated;
    }
    
    public boolean isActive() {
        return active;
    }
    
    public void setActive(boolean active) {
        this.active = active;
    }
    
    // Abstract methods for polymorphism - must be implemented by subclasses
    public abstract String getPersonType();
    public abstract String getDisplayInfo();
    
    // Template method pattern - common behavior with abstract parts
    public final String getFullProfile() {
        StringBuilder profile = new StringBuilder();
        profile.append("=== ").append(getPersonType()).append(" Profile ===\n");
        profile.append("ID: ").append(id).append("\n");
        profile.append("Name: ").append(fullName).append("\n");
        profile.append("Email: ").append(email != null ? email : "Not provided").append("\n");
        profile.append("Created: ").append(dateCreated).append("\n");
        profile.append("Status: ").append(active ? "Active" : "Inactive").append("\n");
        profile.append("\n").append(getDisplayInfo());
        return profile.toString();
    }
    
    // Common utility method
    public void deactivate() {
        this.active = false;
    }
    
    public void reactivate() {
        this.active = true;
    }
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Person person = (Person) obj;
        return Objects.equals(id, person.id);
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
    
    @Override
    public String toString() {
        return fullName + " (" + id + ")";
    }
}