package edu.ccrm.domain;

import java.time.LocalDate;
import java.util.Objects;

/**
 * Course domain class demonstrating encapsulation and business logic
 * Represents a course offering in the system
 */
public class Course {
    private final String code;
    private String title;
    private int credits;
    private String instructorId;
    private Semester semester;
    private String department;
    private LocalDate dateCreated;
    private boolean active;
    private int maxEnrollment;
    private int currentEnrollment;
    
    // Course builder inner class for Builder pattern demonstration
    public static class Builder {
        private final String code;
        private final String title;
        private int credits = 3;
        private String instructorId;
        private Semester semester = Semester.FALL;
        private String department = "General";
        private int maxEnrollment = 30;
        
        public Builder(String code, String title) {
            if (code == null || code.trim().isEmpty()) {
                throw new IllegalArgumentException("Course code cannot be null or empty");
            }
            if (title == null || title.trim().isEmpty()) {
                throw new IllegalArgumentException("Course title cannot be null or empty");
            }
            
            this.code = code.trim().toUpperCase();
            this.title = title.trim();
        }
        
        public Builder credits(int credits) {
            if (credits <= 0 || credits > 6) {
                throw new IllegalArgumentException("Credits must be between 1 and 6");
            }
            this.credits = credits;
            return this;
        }
        
        public Builder instructor(String instructorId) {
            this.instructorId = instructorId;
            return this;
        }
        
        public Builder semester(Semester semester) {
            if (semester == null) {
                throw new IllegalArgumentException("Semester cannot be null");
            }
            this.semester = semester;
            return this;
        }
        
        public Builder department(String department) {
            this.department = department != null ? department.trim() : "General";
            return this;
        }
        
        public Builder maxEnrollment(int maxEnrollment) {
            if (maxEnrollment <= 0) {
                throw new IllegalArgumentException("Max enrollment must be positive");
            }
            this.maxEnrollment = maxEnrollment;
            return this;
        }
        
        public Course build() {
            return new Course(this);
        }
    }
    
    // Private constructor for Builder pattern
    private Course(Builder builder) {
        this.code = builder.code;
        this.title = builder.title;
        this.credits = builder.credits;
        this.instructorId = builder.instructorId;
        this.semester = builder.semester;
        this.department = builder.department;
        this.maxEnrollment = builder.maxEnrollment;
        this.dateCreated = LocalDate.now();
        this.active = true;
        this.currentEnrollment = 0;
    }
    
    // Getters and setters for encapsulation
    public String getCode() {
        return code;
    }
    
    public String getTitle() {
        return title;
    }
    
    public void setTitle(String title) {
        if (title == null || title.trim().isEmpty()) {
            throw new IllegalArgumentException("Course title cannot be null or empty");
        }
        this.title = title.trim();
    }
    
    public int getCredits() {
        return credits;
    }
    
    public void setCredits(int credits) {
        if (credits <= 0 || credits > 6) {
            throw new IllegalArgumentException("Credits must be between 1 and 6");
        }
        this.credits = credits;
    }
    
    public String getInstructorId() {
        return instructorId;
    }
    
    public void setInstructorId(String instructorId) {
        this.instructorId = instructorId;
    }
    
    public Semester getSemester() {
        return semester;
    }
    
    public void setSemester(Semester semester) {
        if (semester == null) {
            throw new IllegalArgumentException("Semester cannot be null");
        }
        this.semester = semester;
    }
    
    public String getDepartment() {
        return department;
    }
    
    public void setDepartment(String department) {
        this.department = department != null ? department.trim() : "General";
    }
    
    public LocalDate getDateCreated() {
        return dateCreated;
    }
    
    public boolean isActive() {
        return active;
    }
    
    public void setActive(boolean active) {
        this.active = active;
    }
    
    public int getMaxEnrollment() {
        return maxEnrollment;
    }
    
    public void setMaxEnrollment(int maxEnrollment) {
        if (maxEnrollment <= 0) {
            throw new IllegalArgumentException("Max enrollment must be positive");
        }
        if (maxEnrollment < currentEnrollment) {
            throw new IllegalArgumentException("Max enrollment cannot be less than current enrollment");
        }
        this.maxEnrollment = maxEnrollment;
    }
    
    public int getCurrentEnrollment() {
        return currentEnrollment;
    }
    
    // Business logic methods
    public boolean hasAvailableSlots() {
        return currentEnrollment < maxEnrollment;
    }
    
    public int getAvailableSlots() {
        return Math.max(0, maxEnrollment - currentEnrollment);
    }
    
    public void incrementEnrollment() {
        if (currentEnrollment >= maxEnrollment) {
            throw new IllegalStateException("Course is at maximum capacity");
        }
        this.currentEnrollment++;
    }
    
    public void decrementEnrollment() {
        if (currentEnrollment > 0) {
            this.currentEnrollment--;
        }
    }
    
    public boolean isFull() {
        return currentEnrollment >= maxEnrollment;
    }
    
    public double getEnrollmentPercentage() {
        return maxEnrollment > 0 ? (double) currentEnrollment / maxEnrollment * 100 : 0;
    }
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Course course = (Course) obj;
        return Objects.equals(code, course.code);
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(code);
    }
    
    @Override
    public String toString() {
        return String.format("%s - %s (%d credits) - %s %s", 
            code, title, credits, semester.getDisplayName(), 
            instructorId != null ? "[" + instructorId + "]" : "[No Instructor]");
    }
}