package edu.ccrm.domain;

/**
 * Semester enumeration with constructors and fields
 * Demonstrates enum with custom constructor and methods
 */
public enum Semester {
    SPRING("Spring", 1, "January-May"),
    SUMMER("Summer", 2, "May-August"), 
    FALL("Fall", 3, "August-December"),
    WINTER("Winter", 4, "December-January");
    
    private final String displayName;
    private final int order;
    private final String duration;
    
    // Enum constructor
    Semester(String displayName, int order, String duration) {
        this.displayName = displayName;
        this.order = order;
        this.duration = duration;
    }
    
    // Getter methods
    public String getDisplayName() {
        return displayName;
    }
    
    public int getOrder() {
        return order;
    }
    
    public String getDuration() {
        return duration;
    }
    
    // Business logic methods
    public Semester getNext() {
        return switch (this) {
            case SPRING -> SUMMER;
            case SUMMER -> FALL;
            case FALL -> WINTER;
            case WINTER -> SPRING;
        };
    }
    
    // Parsing helpers for CSV import/export
    public static Semester fromDisplayName(String displayName) {
        if (displayName == null) {
            throw new IllegalArgumentException("Display name cannot be null");
        }
        
        String trimmed = displayName.trim();
        for (Semester semester : Semester.values()) {
            if (semester.displayName.equalsIgnoreCase(trimmed)) {
                return semester;
            }
        }
        throw new IllegalArgumentException("Invalid semester display name: " + displayName);
    }
    
    public static Semester fromOrder(int order) {
        for (Semester semester : Semester.values()) {
            if (semester.order == order) {
                return semester;
            }
        }
        throw new IllegalArgumentException("Invalid semester order: " + order);
    }
    
    public boolean isAcademicYear() {
        return this == SPRING || this == FALL;
    }
    
    @Override
    public String toString() {
        return displayName + " (" + duration + ")";
    }
}