package edu.ccrm.domain;

/**
 * Grade enumeration with constructors, fields and grade point calculation
 * Demonstrates enum with complex constructor and business logic
 */
public enum Grade {
    S("S", 10.0, "Outstanding", 90, 100),
    A("A", 9.0, "Excellent", 80, 89),
    B("B", 8.0, "Very Good", 70, 79),
    C("C", 7.0, "Good", 60, 69),
    D("D", 6.0, "Satisfactory", 50, 59),
    E("E", 4.0, "Pass", 40, 49),
    F("F", 0.0, "Fail", 0, 39);
    
    private final String letter;
    private final double gradePoint;
    private final String description;
    private final int minMarks;
    private final int maxMarks;
    
    // Enum constructor with multiple parameters
    Grade(String letter, double gradePoint, String description, int minMarks, int maxMarks) {
        this.letter = letter;
        this.gradePoint = gradePoint;
        this.description = description;
        this.minMarks = minMarks;
        this.maxMarks = maxMarks;
    }
    
    // Getter methods
    public String getLetter() {
        return letter;
    }
    
    public double getGradePoint() {
        return gradePoint;
    }
    
    public String getDescription() {
        return description;
    }
    
    public int getMinMarks() {
        return minMarks;
    }
    
    public int getMaxMarks() {
        return maxMarks;
    }
    
    // Business logic methods
    public static Grade fromMarks(int marks) {
        if (marks < 0 || marks > 100) {
            throw new IllegalArgumentException("Marks must be between 0 and 100");
        }
        
        for (Grade grade : Grade.values()) {
            if (marks >= grade.minMarks && marks <= grade.maxMarks) {
                return grade;
            }
        }
        return F; // Fallback
    }
    
    // Parsing helper for CSV import/export
    public static Grade fromLetter(String letter) {
        if (letter == null) {
            throw new IllegalArgumentException("Grade letter cannot be null");
        }
        
        String trimmed = letter.trim().toUpperCase();
        for (Grade grade : Grade.values()) {
            if (grade.letter.equals(trimmed)) {
                return grade;
            }
        }
        throw new IllegalArgumentException("Invalid grade letter: " + letter);
    }
    
    public boolean isPassing() {
        return this != F;
    }
    
    public boolean isHonors() {
        return this == S || this == A;
    }
    
    @Override
    public String toString() {
        return letter + " (" + description + " - " + gradePoint + " points)";
    }
}