package edu.ccrm.exception;

import java.util.*;

/**
 * Exception for data validation errors with detailed field-level feedback
 * Demonstrates comprehensive validation exception with multiple error support
 */
public class DataValidationException extends CCRMException {
    private final Map<String, List<String>> fieldErrors;
    private final List<String> globalErrors;
    
    public DataValidationException(String message) {
        super(message, "DATA_VALIDATION_ERROR");
        this.fieldErrors = new HashMap<>();
        this.globalErrors = new ArrayList<>();
    }
    
    public DataValidationException(String message, Map<String, List<String>> fieldErrors) {
        super(message, "DATA_VALIDATION_ERROR");
        this.fieldErrors = fieldErrors != null ? new HashMap<>(fieldErrors) : new HashMap<>();
        this.globalErrors = new ArrayList<>();
    }
    
    public DataValidationException(String message, Map<String, List<String>> fieldErrors, List<String> globalErrors) {
        super(message, "DATA_VALIDATION_ERROR");
        this.fieldErrors = fieldErrors != null ? new HashMap<>(fieldErrors) : new HashMap<>();
        this.globalErrors = globalErrors != null ? new ArrayList<>(globalErrors) : new ArrayList<>();
    }
    
    // Builder pattern for creating validation exceptions
    public static class Builder {
        private String message = "Data validation failed";
        private Map<String, List<String>> fieldErrors = new HashMap<>();
        private List<String> globalErrors = new ArrayList<>();
        
        public Builder message(String message) {
            this.message = message;
            return this;
        }
        
        public Builder addFieldError(String field, String error) {
            fieldErrors.computeIfAbsent(field, k -> new ArrayList<>()).add(error);
            return this;
        }
        
        public Builder addGlobalError(String error) {
            this.globalErrors.add(error);
            return this;
        }
        
        public DataValidationException build() {
            return new DataValidationException(message, fieldErrors, globalErrors);
        }
    }
    
    public static Builder builder() {
        return new Builder();
    }
    
    public Map<String, List<String>> getFieldErrors() {
        return Collections.unmodifiableMap(fieldErrors);
    }
    
    public List<String> getGlobalErrors() {
        return Collections.unmodifiableList(globalErrors);
    }
    
    public boolean hasFieldErrors() {
        return !fieldErrors.isEmpty();
    }
    
    public boolean hasGlobalErrors() {
        return !globalErrors.isEmpty();
    }
    
    public List<String> getFieldErrors(String field) {
        return fieldErrors.getOrDefault(field, Collections.emptyList());
    }
    
    public int getTotalErrorCount() {
        return fieldErrors.values().stream().mapToInt(List::size).sum() + globalErrors.size();
    }
    
    @Override
    public String getDetailedMessage() {
        StringBuilder sb = new StringBuilder();
        sb.append(super.getDetailedMessage());
        
        if (hasGlobalErrors()) {
            sb.append("\nGlobal Errors:");
            globalErrors.forEach(error -> sb.append("\n  - ").append(error));
        }
        
        if (hasFieldErrors()) {
            sb.append("\nField Errors:");
            fieldErrors.forEach((field, errors) -> {
                sb.append("\n  ").append(field).append(":");
                errors.forEach(error -> sb.append("\n    - ").append(error));
            });
        }
        
        return sb.toString();
    }
}