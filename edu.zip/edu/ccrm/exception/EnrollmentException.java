package edu.ccrm.exception;

/**
 * Exception thrown for enrollment-related business rule violations
 * Demonstrates exception handling for complex business logic
 */
public class EnrollmentException extends CCRMException {
    
    public enum EnrollmentError {
        COURSE_FULL("ENROLLMENT_COURSE_FULL", "Course has reached maximum enrollment"),
        ALREADY_ENROLLED("ENROLLMENT_DUPLICATE", "Student is already enrolled in this course"),
        ENROLLMENT_NOT_FOUND("ENROLLMENT_NOT_FOUND", "Enrollment record not found"),
        COURSE_INACTIVE("ENROLLMENT_COURSE_INACTIVE", "Course is not active for enrollment"),
        STUDENT_INACTIVE("ENROLLMENT_STUDENT_INACTIVE", "Student account is not active"),
        PREREQUISITES_NOT_MET("ENROLLMENT_PREREQUISITES", "Student does not meet course prerequisites"),
        CREDIT_LIMIT_EXCEEDED("ENROLLMENT_CREDIT_LIMIT", "Enrollment would exceed student credit limit"),
        SCHEDULE_CONFLICT("ENROLLMENT_SCHEDULE_CONFLICT", "Schedule conflict with existing enrollments"),
        LATE_ENROLLMENT("ENROLLMENT_LATE", "Enrollment period has ended for this course");
        
        private final String errorCode;
        private final String description;
        
        EnrollmentError(String errorCode, String description) {
            this.errorCode = errorCode;
            this.description = description;
        }
        
        public String getErrorCode() {
            return errorCode;
        }
        
        public String getDescription() {
            return description;
        }
    }
    
    private final EnrollmentError enrollmentError;
    private final String studentId;
    private final String courseCode;
    
    public EnrollmentException(EnrollmentError error, String studentId, String courseCode) {
        super(error.getDescription(), error.getErrorCode(), 
              "Student: " + studentId + ", Course: " + courseCode);
        this.enrollmentError = error;
        this.studentId = studentId;
        this.courseCode = courseCode;
    }
    
    public EnrollmentException(EnrollmentError error, String studentId, String courseCode, String additionalMessage) {
        super(error.getDescription() + " - " + additionalMessage, error.getErrorCode(), 
              "Student: " + studentId + ", Course: " + courseCode);
        this.enrollmentError = error;
        this.studentId = studentId;
        this.courseCode = courseCode;
    }
    
    public EnrollmentException(EnrollmentError error, String studentId, String courseCode, Throwable cause) {
        super(error.getDescription(), error.getErrorCode(), 
              "Student: " + studentId + ", Course: " + courseCode, cause);
        this.enrollmentError = error;
        this.studentId = studentId;
        this.courseCode = courseCode;
    }
    
    public EnrollmentError getEnrollmentError() {
        return enrollmentError;
    }
    
    public String getStudentId() {
        return studentId;
    }
    
    public String getCourseCode() {
        return courseCode;
    }
}