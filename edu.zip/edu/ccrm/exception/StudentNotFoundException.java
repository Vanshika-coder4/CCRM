package edu.ccrm.exception;

/**
 * Exception thrown when a student cannot be found by ID or registration number
 * Demonstrates specific exception for domain-level errors
 */
public class StudentNotFoundException extends CCRMException {
    private final String studentIdentifier;
    
    public StudentNotFoundException(String studentId) {
        super("Student not found: " + studentId, "STUDENT_NOT_FOUND", 
              "Student lookup by ID: " + studentId);
        this.studentIdentifier = studentId;
    }
    
    public StudentNotFoundException(String studentId, String searchType) {
        super("Student not found: " + studentId + " (search by " + searchType + ")", 
              "STUDENT_NOT_FOUND", 
              "Student lookup by " + searchType + ": " + studentId);
        this.studentIdentifier = studentId;
    }
    
    public String getStudentIdentifier() {
        return studentIdentifier;
    }
}