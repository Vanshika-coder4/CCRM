package edu.ccrm.exception;

/**
 * Exception thrown when a course cannot be found by code
 * Demonstrates specific exception for course-related operations
 */
public class CourseNotFoundException extends CCRMException {
    private final String courseCode;
    
    public CourseNotFoundException(String courseCode) {
        super("Course not found: " + courseCode, "COURSE_NOT_FOUND", 
              "Course lookup by code: " + courseCode);
        this.courseCode = courseCode;
    }
    
    public CourseNotFoundException(String courseCode, String message) {
        super(message, "COURSE_NOT_FOUND", 
              "Course operation on: " + courseCode);
        this.courseCode = courseCode;
    }
    
    public String getCourseCode() {
        return courseCode;
    }
}