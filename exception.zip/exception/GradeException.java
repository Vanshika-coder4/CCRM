package edu.ccrm.exception;

/**
 * Exception thrown for grade-related operations and validation errors
 * Demonstrates validation exception with detailed error context
 */
public class GradeException extends CCRMException {
    
    public enum GradeError {
        INVALID_MARKS("GRADE_INVALID_MARKS", "Marks must be between 0 and 100"),
        INVALID_GRADE("GRADE_INVALID", "Invalid grade letter or format"),
        ENROLLMENT_NOT_FOUND("GRADE_ENROLLMENT_NOT_FOUND", "Cannot record grade - enrollment not found"),
        ALREADY_GRADED("GRADE_ALREADY_RECORDED", "Grade has already been recorded for this enrollment"),
        COURSE_NOT_COMPLETED("GRADE_COURSE_INCOMPLETE", "Cannot record final grade - course not completed"),
        GRADE_CALCULATION_ERROR("GRADE_CALCULATION_ERROR", "Error calculating GPA or grade statistics"),
        TRANSCRIPT_GENERATION_ERROR("GRADE_TRANSCRIPT_ERROR", "Error generating transcript");
        
        private final String errorCode;
        private final String description;
        
        GradeError(String errorCode, String description) {
            this.errorCode = errorCode;
            this.description = description;
        }
        
        public String getErrorCode() {
            return errorCode;
        }
        
        public String getDescription() {
            return description;
        }
    }
    
    private final GradeError gradeError;
    private final Object value;
    
    public GradeException(GradeError error) {
        super(error.getDescription(), error.getErrorCode());
        this.gradeError = error;
        this.value = null;
    }
    
    public GradeException(GradeError error, Object value) {
        super(error.getDescription() + " (Value: " + value + ")", error.getErrorCode(), 
              "Invalid value: " + value);
        this.gradeError = error;
        this.value = value;
    }
    
    public GradeException(GradeError error, String context, Throwable cause) {
        super(error.getDescription(), error.getErrorCode(), context, cause);
        this.gradeError = error;
        this.value = null;
    }
    
    public GradeError getGradeError() {
        return gradeError;
    }
    
    public Object getValue() {
        return value;
    }
}