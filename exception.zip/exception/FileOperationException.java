package edu.ccrm.exception;

import java.nio.file.Path;

/**
 * Exception for file I/O and CSV operations with detailed path information
 * Demonstrates I/O exception handling with context preservation
 */
public class FileOperationException extends CCRMException {
    
    public enum FileError {
        FILE_NOT_FOUND("FILE_NOT_FOUND", "File not found"),
        FILE_ACCESS_DENIED("FILE_ACCESS_DENIED", "Access denied to file"),
        INVALID_FILE_FORMAT("FILE_INVALID_FORMAT", "Invalid file format"),
        CSV_PARSING_ERROR("FILE_CSV_PARSING", "Error parsing CSV file"),
        CSV_EXPORT_ERROR("FILE_CSV_EXPORT", "Error exporting to CSV"),
        BACKUP_CREATION_ERROR("FILE_BACKUP_CREATE", "Error creating backup"),
        BACKUP_RESTORE_ERROR("FILE_BACKUP_RESTORE", "Error restoring from backup"),
        DIRECTORY_CREATION_ERROR("FILE_DIRECTORY_CREATE", "Error creating directory"),
        FILE_COPY_ERROR("FILE_COPY_ERROR", "Error copying file"),
        FILE_MOVE_ERROR("FILE_MOVE_ERROR", "Error moving file");
        
        private final String errorCode;
        private final String description;
        
        FileError(String errorCode, String description) {
            this.errorCode = errorCode;
            this.description = description;
        }
        
        public String getErrorCode() {
            return errorCode;
        }
        
        public String getDescription() {
            return description;
        }
    }
    
    private final FileError fileError;
    private final Path filePath;
    private final int lineNumber;
    
    public FileOperationException(FileError error, Path filePath) {
        super(error.getDescription() + ": " + filePath, error.getErrorCode(), 
              "File: " + filePath);
        this.fileError = error;
        this.filePath = filePath;
        this.lineNumber = -1;
    }
    
    public FileOperationException(FileError error, Path filePath, Throwable cause) {
        super(error.getDescription() + ": " + filePath, error.getErrorCode(), 
              "File: " + filePath, cause);
        this.fileError = error;
        this.filePath = filePath;
        this.lineNumber = -1;
    }
    
    public FileOperationException(FileError error, Path filePath, int lineNumber, String message) {
        super(error.getDescription() + ": " + message + " (line " + lineNumber + ")", 
              error.getErrorCode(), 
              "File: " + filePath + ", Line: " + lineNumber);
        this.fileError = error;
        this.filePath = filePath;
        this.lineNumber = lineNumber;
    }
    
    public FileOperationException(FileError error, Path filePath, int lineNumber, Throwable cause) {
        super(error.getDescription() + " at line " + lineNumber, error.getErrorCode(), 
              "File: " + filePath + ", Line: " + lineNumber, cause);
        this.fileError = error;
        this.filePath = filePath;
        this.lineNumber = lineNumber;
    }
    
    public FileError getFileError() {
        return fileError;
    }
    
    public Path getFilePath() {
        return filePath;
    }
    
    public int getLineNumber() {
        return lineNumber;
    }
    
    public boolean hasLineNumber() {
        return lineNumber > 0;
    }
}